import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";

// Initialize the Gemini API with the API key from environment variables
const API_KEY = process.env.GEMINI_API_KEY;
if (!API_KEY) {
  throw new Error("GEMINI_API_KEY environment variable is not set");
}

const genAI = new GoogleGenerativeAI(API_KEY);

// Gemini model configuration
const modelName = "gemini-1.5-pro";
const generationConfig = {
  temperature: 0.7,
  topK: 40,
  topP: 0.95,
  maxOutputTokens: 2048,
};

// Safety settings to prevent harmful content
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
];

// Ayurvedic expert system prompt to guide the model
const AYURVEDIC_SYSTEM_PROMPT = `
You are an Ayurvedic consultant assistant named Vedic Genie. Your purpose is to provide accurate, helpful information about Ayurvedic medicine, health practices, and wellness based on traditional Ayurvedic principles.

Follow these guidelines:
1. Base your responses on traditional Ayurvedic texts and recognized Ayurvedic principles.
2. Provide balanced information about the three doshas (Vata, Pitta, Kapha) and their influence on health.
3. When discussing treatments, herbs, or remedies, explain their traditional uses and properties.
4. Clarify that your information is educational and not a substitute for professional medical advice.
5. Be respectful of both traditional Ayurvedic knowledge and modern scientific understanding.
6. Include Sanskrit terms where appropriate, but always explain them in simple terms.
7. Focus on holistic wellness, balance, and prevention through lifestyle, diet, and natural remedies.
8. When appropriate, recommend consulting with a qualified Ayurvedic practitioner for personalized advice.

Your tone should be helpful, respectful, and educational. Provide thoughtful, comprehensive answers that reflect the depth of Ayurvedic knowledge while being accessible to people who may be new to Ayurveda.
`;

/**
 * Generates a response from the Gemini AI model based on an Ayurvedic query
 * @param query The user's question or message
 * @param conversationHistory Previous messages in the conversation for context
 * @returns A string containing the AI's response
 */
export async function generateAyurvedicResponse(
  query: string,
  conversationHistory: any[] = []
): Promise<string> {
  try {
    // Get the model
    const model = genAI.getGenerativeModel({
      model: modelName,
      generationConfig,
      safetySettings,
    });

    // Convert message history to the format expected by Gemini
    const formattedHistory = conversationHistory.map(msg => {
      if (msg.role === "user") {
        return { role: "user", parts: [{ text: msg.content }] };
      } else {
        return { role: "model", parts: [{ text: msg.content }] };
      }
    });

    // Create a chat session
    const chat = model.startChat({
      history: formattedHistory,
      generationConfig,
      safetySettings,
      systemInstruction: AYURVEDIC_SYSTEM_PROMPT,
    });

    // Generate a response to the user's message
    const result = await chat.sendMessage(query);
    const response = result.response;
    const text = response.text();

    return text;
  } catch (error) {
    console.error("Error generating Ayurvedic response:", error);
    return "I apologize, but I'm having trouble connecting to my knowledge base right now. Please try again in a moment.";
  }
}

/**
 * Analyzes a set of symptoms using the Gemini AI model to suggest possible Ayurvedic conditions and treatments
 * @param symptoms Array of symptom descriptions
 * @param userInfo Additional user information like age, gender, constitution
 * @returns A structured analysis of possible conditions and recommendations
 */
export async function analyzeSymptoms(
  symptoms: string[],
  userInfo?: { age?: string; gender?: string; constitution?: string }
): Promise<string> {
  if (!symptoms.length) {
    return "Please provide at least one symptom for analysis.";
  }

  try {
    // Format the symptoms and user info into a structured query
    let analysisPrompt = "Based on Ayurvedic principles, analyze these symptoms:\n";
    symptoms.forEach((symptom, index) => {
      analysisPrompt += `${index + 1}. ${symptom}\n`;
    });

    if (userInfo) {
      analysisPrompt += "\nAdditional information:\n";
      if (userInfo.age) analysisPrompt += `Age: ${userInfo.age}\n`;
      if (userInfo.gender) analysisPrompt += `Gender: ${userInfo.gender}\n`;
      if (userInfo.constitution) 
        analysisPrompt += `Known dosha constitution: ${userInfo.constitution}\n`;
    }

    analysisPrompt += `\nPlease provide:
1. Potential dosha imbalances
2. Possible Ayurvedic conditions
3. Recommended dietary adjustments
4. Suggested lifestyle changes
5. Beneficial herbs or remedies
6. When to consult an Ayurvedic practitioner

Format your response in a clear, organized manner with headings for each section.`;

    // Get the model
    const model = genAI.getGenerativeModel({
      model: modelName,
      generationConfig,
      safetySettings,
    });

    // Generate the analysis
    const result = await model.generateContent([
      AYURVEDIC_SYSTEM_PROMPT,
      analysisPrompt,
    ]);
    const response = result.response;
    const text = response.text();

    return text;
  } catch (error) {
    console.error("Error analyzing symptoms:", error);
    return "I apologize, but I'm having trouble analyzing your symptoms right now. Please try again in a moment.";
  }
}