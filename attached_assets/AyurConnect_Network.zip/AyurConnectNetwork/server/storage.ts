import { 
  users, type User, type InsertUser, type UpsertUser,
  posts, type Post, type InsertPost,
  comments, type Comment, type InsertComment,
  pdfs, type Pdf, type InsertPdf,
  messages, type Message, type InsertMessage,
  replies, type Reply, type InsertReply 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Post operations
  getPost(id: number): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number): Promise<Post[]>;
  getPostsByUser(userId: string): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  
  // Comment operations
  getCommentsByPost(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // PDF operations
  getPdfsByUser(userId: string): Promise<Pdf[]>;
  createPdf(pdf: InsertPdf): Promise<Pdf>;
  
  // Message operations
  getMessagesByUser(userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Reply operations
  getRepliesByMessage(messageId: number): Promise<Reply[]>;
  createReply(reply: InsertReply): Promise<Reply>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Post operations
  async getPost(id: number): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }

  async getPosts(limit = 10, offset = 0): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getPostsByUser(userId: string): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values(insertPost)
      .returning();
    return post;
  }

  // Comment operations
  async getCommentsByPost(postId: number): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.createdAt));
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values(insertComment)
      .returning();
    return comment;
  }

  // PDF operations
  async getPdfsByUser(userId: string): Promise<Pdf[]> {
    return await db
      .select()
      .from(pdfs)
      .where(eq(pdfs.userId, userId))
      .orderBy(desc(pdfs.uploadedAt));
  }

  async createPdf(insertPdf: InsertPdf): Promise<Pdf> {
    const [pdf] = await db
      .insert(pdfs)
      .values(insertPdf)
      .returning();
    return pdf;
  }

  // Message operations
  async getMessagesByUser(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.userId, userId))
      .orderBy(asc(messages.createdAt));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }

  // Reply operations
  async getRepliesByMessage(messageId: number): Promise<Reply[]> {
    return await db
      .select()
      .from(replies)
      .where(eq(replies.messageId, messageId))
      .orderBy(asc(replies.createdAt));
  }

  async createReply(insertReply: InsertReply): Promise<Reply> {
    const [reply] = await db
      .insert(replies)
      .values(insertReply)
      .returning();
    return reply;
  }
}

export const storage = new DatabaseStorage();
