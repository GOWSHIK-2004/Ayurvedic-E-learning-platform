import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import path from "path";
import fs from "fs";
import multer from "multer";
import cookieParser from "cookie-parser";
import { z } from "zod";

import { storage } from "./storage";
import {
  generateAyurvedicResponse,
  analyzeSymptoms,
} from "./services/gemini";
import {
  insertPostSchema,
  insertCommentSchema,
  insertMessageSchema,
  insertReplySchema,
} from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());
  app.use(express.static("public"));

  await setupAuth(app);

  // File Upload Configuration
  const uploadsDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

  const storageConfig = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, `${file.fieldname}-${unique}${path.extname(file.originalname)}`);
    },
  });

  const upload = multer({
    storage: storageConfig,
    fileFilter: (_req, file, cb) =>
      file.mimetype === "application/pdf"
        ? cb(null, true)
        : cb(new Error("Only PDF files are allowed")),
    limits: { fileSize: 10 * 1024 * 1024 },
  });

  // Authentication
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      res.json(user);
    } catch (err) {
      console.error("Auth Error:", err);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // PDF Uploads
  app.post("/api/pdfs/upload", upload.single("pdf"), async (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });
      const userId = parseInt(req.body.userId);
      if (isNaN(userId)) return res.status(400).json({ message: "Invalid userId" });

      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const newPdf = await storage.createPdf({
        userId,
        filename: req.file.originalname,
        path: req.file.path,
      });
      res.status(201).json(newPdf);
    } catch {
      res.status(500).json({ message: "Error uploading PDF" });
    }
  });

  app.get("/api/pdfs/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) return res.status(400).json({ message: "Invalid userId" });

      const pdfs = await storage.getPdfsByUser(userId);
      res.status(200).json(pdfs);
    } catch {
      res.status(500).json({ message: "Error retrieving PDFs" });
    }
  });

  // Forum Posts
  app.get("/api/posts", async (_req, res) => {
    try {
      const posts = await storage.getPosts(10, 0);
      const postsWithUsers = await Promise.all(posts.map(async post => ({
        ...post,
        user: await storage.getUser(post.userId),
      })));
      res.status(200).json(postsWithUsers);
    } catch {
      res.status(500).json({ message: "Error retrieving posts" });
    }
  });

  app.post("/api/posts", async (req, res) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      const user = await storage.getUser(postData.userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const newPost = await storage.createPost(postData);
      res.status(201).json({ ...newPost, user });
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: "Invalid post data", errors: err.errors });
      res.status(500).json({ message: "Error creating post" });
    }
  });

  // Comments
  app.get("/api/posts/:postId/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.postId);
      if (isNaN(postId)) return res.status(400).json({ message: "Invalid postId" });

      const comments = await storage.getCommentsByPost(postId);
      const withUsers = await Promise.all(comments.map(async comment => ({
        ...comment,
        user: await storage.getUser(comment.userId),
      })));
      res.status(200).json(withUsers);
    } catch {
      res.status(500).json({ message: "Error retrieving comments" });
    }
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const commentData = insertCommentSchema.parse(req.body);
      const user = await storage.getUser(commentData.userId);
      const post = await storage.getPost(commentData.postId);
      if (!user || !post)
        return res.status(404).json({ message: "User or post not found" });

      const newComment = await storage.createComment(commentData);
      res.status(201).json({ ...newComment, user });
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: "Invalid comment data", errors: err.errors });
      res.status(500).json({ message: "Error creating comment" });
    }
  });

  // Messages & Replies
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const user = await storage.getUser(messageData.userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const newMessage = await storage.createMessage(messageData);
      res.status(201).json({ ...newMessage, user });
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: "Invalid message data", errors: err.errors });
      res.status(500).json({ message: "Error creating message" });
    }
  });

  app.get("/api/messages/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) return res.status(400).json({ message: "Invalid userId" });

      const messages = await storage.getMessagesByUser(userId);
      const withReplies = await Promise.all(messages.map(async message => ({
        ...message,
        replies: await storage.getRepliesByMessage(message.id),
      })));
      res.status(200).json(withReplies);
    } catch {
      res.status(500).json({ message: "Error retrieving messages" });
    }
  });

  app.post("/api/replies", async (req, res) => {
    try {
      const replyData = insertReplySchema.parse(req.body);
      const message = await storage.getMessage(replyData.messageId);
      if (!message) return res.status(404).json({ message: "Message not found" });

      const newReply = await storage.createReply(replyData);
      res.status(201).json(newReply);
    } catch (err) {
      if (err instanceof z.ZodError)
        return res.status(400).json({ message: "Invalid reply data", errors: err.errors });
      res.status(500).json({ message: "Error creating reply" });
    }
  });

  // Gemini AI
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { query, conversationHistory } = req.body;
      if (!query) return res.status(400).json({ message: "Query is required" });

      const response = await generateAyurvedicResponse(query, conversationHistory || []);
      res.status(200).json({ response });
    } catch (err) {
      res.status(500).json({ message: "Error generating AI response", error: err instanceof Error ? err.message : "Unknown error" });
    }
  });

  app.post("/api/ai/analyze-symptoms", async (req, res) => {
    try {
      const { symptoms, userInfo } = req.body;
      if (!Array.isArray(symptoms) || symptoms.length === 0)
        return res.status(400).json({ message: "Valid symptoms array required" });

      const analysis = await analyzeSymptoms(symptoms, userInfo);
      res.status(200).json({ analysis });
    } catch (err) {
      res.status(500).json({ message: "Error analyzing symptoms", error: err instanceof Error ? err.message : "Unknown error" });
    }
  });

  return httpServer;
}
