// server/replitAuth.ts

import type { RequestHandler, Express } from "express";

/**
 * No-op session middleware for local development.
 */
export function getSession(): RequestHandler {
  return (_req, _res, next) => next();
}

/**
 * No-op initializer (used in server/index.ts).
 */
export async function setupAuth(_app: Express): Promise<void> {
  // nothing to do here
}

/**
 * No-op guard middleware (used to protect routes).
 */
export const isAuthenticated = (req, res, next) => {
  try {
    const userId = req.headers['x-replit-user-id'];
    const userName = req.headers['x-replit-user-name'];

    if (!userId || !userName) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    req.user = {
      claims: {
        id: userId,
        name: userName,
      },
    };

    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ message: 'Unauthorized' });
  }
};
