export interface User {
  id: number;
  username: string;
  displayName?: string;
  dosha?: string;
  specialization?: string;
  profileImage?: string;
  createdAt: Date;
}

export interface Post {
  id: number;
  userId: number;
  title: string;
  content: string;
  tags: string[];
  createdAt: Date;
  user?: {
    id: number;
    username: string;
    displayName?: string;
  };
}

export interface Comment {
  id: number;
  userId: number;
  postId: number;
  content: string;
  createdAt: Date;
  user?: {
    id: number;
    username: string;
    displayName?: string;
  };
}

export interface Pdf {
  id: number;
  userId: number;
  filename: string;
  path: string;
  uploadedAt: Date;
}

export interface Message {
  id: number;
  userId: number;
  content: string;
  mode: string;
  pdfId?: number;
  createdAt: Date;
  user?: {
    id: number;
    username: string;
    displayName?: string;
  };
  replies?: Reply[];
}

export interface Reply {
  id: number;
  messageId: number;
  content: string;
  createdAt: Date;
}

export interface HerbInfo {
  id: number;
  name: string;
  category: string;
  description: string;
  image: string;
}

export interface WisdomQuote {
  id: number;
  text: string;
}

export interface BodyPart {
  id: number;
  name: string;
  svgId: string;
  description?: string;
}

export interface Symptom {
  id: number;
  name: string;
  description?: string;
  bodyPartId: number;
  bodyPart?: BodyPart;
}

export interface Condition {
  id: number;
  name: string;
  description: string;
  doshaImbalance?: string;
  commonSymptoms?: string;
  ayurvedicTreatment: string;
  symptoms?: Symptom[];
}

export interface ConditionSymptom {
  id: number;
  conditionId: number;
  symptomId: number;
}

export interface AyurvedicFact {
  id: number;
  title: string;
  content: string;
  imageUrl?: string;
  createdAt: Date;
}

export interface UserSymptom {
  id: string; // Client-side ID
  symptomId: number;
  name: string;
}

export interface SymptomAnalysis {
  matchedConditions: Condition[];
  topMatch?: Condition;
}
