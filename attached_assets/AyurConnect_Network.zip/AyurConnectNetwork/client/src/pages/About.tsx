import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <h1 className="font-heading text-4xl text-earth mb-6 text-center">About Vedic Genie</h1>
            
            <Card className="bg-white rounded-xl natural-shadow mb-8">
              <CardContent className="p-8">
                <h2 className="font-heading text-2xl text-earth mb-4">Our Mission</h2>
                <p className="text-earth-light mb-6">
                  Vedic Genie was created to bridge the gap between ancient Ayurvedic wisdom and modern healing practices. 
                  Our platform serves as a digital sanctuary where practitioners, students, and enthusiasts can connect, 
                  share knowledge, and enhance their understanding of this profound healing science.
                </p>
                
                <h2 className="font-heading text-2xl text-earth mb-4">The Platform</h2>
                <p className="text-earth-light mb-3">
                  Our community-driven platform offers several key features:
                </p>
                <ul className="list-disc pl-6 text-earth-light space-y-2 mb-6">
                  <li>
                    <span className="text-earth font-medium">Interactive Forum:</span> A space for asking questions, sharing insights, and discussing Ayurvedic concepts and practices.
                  </li>
                  <li>
                    <span className="text-earth font-medium">Ayurvedic Assistant:</span> Get answers to your questions based on traditional texts and modern interpretations.
                  </li>
                  <li>
                    <span className="text-earth font-medium">Document Analysis:</span> Upload and analyze traditional texts and research papers related to Ayurveda.
                  </li>
                  <li>
                    <span className="text-earth font-medium">Resource Library:</span> Access a growing collection of Ayurvedic knowledge, organized by doshas, herbs, and practices.
                  </li>
                </ul>
                
                <div className="bg-cream p-6 rounded-lg mb-6">
                  <p className="font-script text-accent text-center text-2xl">
                    "When you understand the principles of Ayurveda, you understand the interconnectedness of all life"
                  </p>
                </div>
                
                <h2 className="font-heading text-2xl text-earth mb-4">Our Approach</h2>
                <p className="text-earth-light mb-6">
                  We believe that Ayurveda is not just a medical system but a comprehensive lifestyle science that promotes 
                  harmony between body, mind, and spirit. Our platform embraces both traditional knowledge and modern research, 
                  creating a space where ancient wisdom meets contemporary understanding.
                </p>
                
                <h2 className="font-heading text-2xl text-earth mb-4">Join Our Community</h2>
                <p className="text-earth-light">
                  Whether you're a seasoned practitioner, a student, or simply curious about Ayurveda, 
                  we welcome you to join our community. Share your knowledge, ask questions, and contribute to 
                  the global revival of this timeless healing tradition.
                </p>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-white rounded-xl natural-shadow text-center">
                <CardContent className="p-6">
                  <div className="text-primary text-3xl mb-3">
                    <i className="ri-ancient-gate-fill"></i>
                  </div>
                  <h3 className="font-heading text-xl text-earth mb-2">Rooted in Tradition</h3>
                  <p className="text-earth-light text-sm">
                    Built on the foundation of classical Ayurvedic texts and traditional knowledge systems
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white rounded-xl natural-shadow text-center">
                <CardContent className="p-6">
                  <div className="text-primary text-3xl mb-3">
                    <i className="ri-global-line"></i>
                  </div>
                  <h3 className="font-heading text-xl text-earth mb-2">Global Community</h3>
                  <p className="text-earth-light text-sm">
                    Connecting Ayurvedic practitioners and enthusiasts from around the world
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-white rounded-xl natural-shadow text-center">
                <CardContent className="p-6">
                  <div className="text-primary text-3xl mb-3">
                    <i className="ri-share-forward-line"></i>
                  </div>
                  <h3 className="font-heading text-xl text-earth mb-2">Knowledge Sharing</h3>
                  <p className="text-earth-light text-sm">
                    Facilitating the exchange of ideas, practices, and research in Ayurvedic medicine
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="text-center">
              <h2 className="font-heading text-2xl text-earth mb-4">Contact Us</h2>
              <p className="text-earth-light mb-6">
                Have questions, suggestions, or feedback? We'd love to hear from you.
              </p>
              <p className="text-earth-light">
                <i className="ri-mail-line mr-2"></i> contact@vedicgenie.com
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
