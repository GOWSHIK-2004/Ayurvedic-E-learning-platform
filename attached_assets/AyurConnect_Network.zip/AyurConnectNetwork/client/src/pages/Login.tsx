import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/auth/user')
      .then(res => res.json())
      .then(data => {
        setUser(data.user);
      })
      .catch(err => console.error('Login error:', err));
  }, []);

  const handleLogin = () => {
    window.location.href = '/api/login';
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1 className="login-title">Vedic Genie</h1>
        <p className="login-subtitle">Unlock the wisdom of Ayurveda</p>
        {!user ? (
          <button onClick={handleLogin} className="login-button">Login with Replit</button>
        ) : (
          <button onClick={() => navigate('/home')} className="login-button">Continue as {user.name}</button>
        )}
      </div>
    </div>
  );
};

export default Login;
