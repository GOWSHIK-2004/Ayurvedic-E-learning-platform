import { useContext } from "react";
import { UserContext } from "@/App";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import ForumHighlights from "@/components/ForumHighlights";
import AyurvedicWisdom from "@/components/AyurvedicWisdom";
import { FactsCarousel } from "@/components/FactsCarousel";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Home() {
  const { user } = useContext(UserContext);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow">
        <div className="container mx-auto px-4 py-10">
          {/* Hero Section with Carousel */}
          <div className="mb-16">
            <FactsCarousel />

            <div className="text-center mt-10">
              <h1 className="font-heading text-4xl md:text-5xl text-earth font-semibold mb-4">
                Welcome to the Ayurvedic Wisdom Community
              </h1>
              <p className="text-earth-light text-lg max-w-3xl mx-auto mb-8">
                Connect with practitioners, share knowledge, and deepen your understanding of Ayurveda's ancient healing traditions
              </p>
              
              {!user && (
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/register">
                    <Button className="bg-primary hover:bg-primary-light text-white px-8 py-6 rounded-lg text-lg">
                      Join Our Community
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white px-8 py-6 rounded-lg text-lg">
                      Sign In
                    </Button>
                  </Link>
                </div>
              )}
              
              {user && (
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/chat">
                    <Button className="bg-primary hover:bg-primary-light text-white px-8 py-6 rounded-lg text-lg">
                      Start a Conversation
                    </Button>
                  </Link>
                  <Link href="/forum">
                    <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white px-8 py-6 rounded-lg text-lg">
                      Browse Forum
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
          
          {/* Features Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl natural-shadow text-center">
              <div className="text-secondary text-3xl mb-4">
                <i className="ri-discuss-line"></i>
              </div>
              <h3 className="font-heading text-xl text-earth font-semibold mb-2">
                Community Forum
              </h3>
              <p className="text-earth-light">
                Ask questions, share insights, and connect with Ayurvedic experts from around the world
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl natural-shadow text-center">
              <div className="text-secondary text-3xl mb-4">
                <i className="ri-chat-voice-line"></i>
              </div>
              <h3 className="font-heading text-xl text-earth font-semibold mb-2">
                Ayurvedic Assistant
              </h3>
              <p className="text-earth-light">
                Get personalized guidance based on ancient texts and modern Ayurvedic practices
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl natural-shadow text-center">
              <div className="text-secondary text-3xl mb-4">
                <i className="ri-heart-pulse-line"></i>
              </div>
              <h3 className="font-heading text-xl text-earth font-semibold mb-2">
                Symptom Analyzer
              </h3>
              <p className="text-earth-light">
                Identify dosha imbalances by selecting body parts and symptoms for personalized recommendations
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl natural-shadow text-center">
              <div className="text-secondary text-3xl mb-4">
                <i className="ri-file-list-3-line"></i>
              </div>
              <h3 className="font-heading text-xl text-earth font-semibold mb-2">
                Resource Library
              </h3>
              <p className="text-earth-light">
                Upload and analyze PDFs of traditional texts and modern research on Ayurvedic medicine
              </p>
            </div>
          </div>
          
          {/* Forum Highlights */}
          <ForumHighlights />
          
          {/* Seasonal Wisdom */}
          <AyurvedicWisdom />
        </div>
      </main>

      <Footer />
    </div>
  );
}
