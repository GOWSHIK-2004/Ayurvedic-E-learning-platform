import { useState, useContext } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { UserContext } from "@/App";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "wouter";

// Registration form schema
const formSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  displayName: z.string().min(1, "Display name is required"),
  dosha: z.string().optional(),
  specialization: z.string().optional(),
});

export default function Register() {
  const [, navigate] = useLocation();
  const { setUser } = useContext(UserContext);
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Initialize form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      password: "",
      displayName: "",
      dosha: "Unknown",
      specialization: "Ayurveda Enthusiast",
    },
  });

  // Handle form submission
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsLoading(true);

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Registration failed");
      }

      const userData = await response.json();
      setUser(userData);
      
      toast({
        title: "Registration successful",
        description: `Welcome to Vedic Genie, ${userData.username}!`,
      });
      
      navigate("/chat");
    } catch (error) {
      toast({
        title: "Registration failed",
        description: "Username may already be taken. Please try a different one.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card className="bg-white rounded-xl natural-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-6">
                <div className="text-secondary text-2xl mr-2">
                  <i className="ri-user-add-line"></i>
                </div>
                <h1 className="font-heading text-2xl text-earth">Create Account</h1>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-earth">Username</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Choose a username"
                            className="bg-cream border-cream-dark"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-earth">Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Create a password"
                            className="bg-cream border-cream-dark"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="displayName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-earth">Display Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Your public display name"
                            className="bg-cream border-cream-dark"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dosha"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-earth">Your Dosha</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-cream border-cream-dark">
                              <SelectValue placeholder="Select your dominant dosha" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Vata">Vata</SelectItem>
                            <SelectItem value="Pitta">Pitta</SelectItem>
                            <SelectItem value="Kapha">Kapha</SelectItem>
                            <SelectItem value="Vata-Pitta">Vata-Pitta</SelectItem>
                            <SelectItem value="Pitta-Kapha">Pitta-Kapha</SelectItem>
                            <SelectItem value="Vata-Kapha">Vata-Kapha</SelectItem>
                            <SelectItem value="Unknown">Not Sure</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="specialization"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-earth">Specialization</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-cream border-cream-dark">
                              <SelectValue placeholder="Your area of interest" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Herbalist">Herbalist</SelectItem>
                            <SelectItem value="Practitioner">Practitioner</SelectItem>
                            <SelectItem value="Yoga">Yoga</SelectItem>
                            <SelectItem value="Student">Student</SelectItem>
                            <SelectItem value="Researcher">Researcher</SelectItem>
                            <SelectItem value="Ayurveda Enthusiast">Enthusiast</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary-light"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <i className="ri-loader-2-line animate-spin mr-2"></i> Creating Account...
                      </>
                    ) : (
                      <>Register</>
                    )}
                  </Button>
                </form>
              </Form>

              <div className="mt-4 text-center text-sm text-earth-light">
                <p>
                  Already have an account?{" "}
                  <Link href="/login">
                    <a className="text-primary hover:text-primary-dark transition-all">
                      Login
                    </a>
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
