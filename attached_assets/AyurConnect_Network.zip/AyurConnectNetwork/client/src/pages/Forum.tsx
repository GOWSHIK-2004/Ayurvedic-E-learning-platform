import { useState, useContext } from "react";
import { UserContext } from "@/App";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import ForumCard from "@/components/ForumCard";
import { Post } from "@/lib/types";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function Forum() {
  const { user } = useContext(UserContext);
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostTags, setNewPostTags] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Demo posts - would be fetched from API in a real application
  const [posts, setPosts] = useState<Post[]>([
    {
      id: 1,
      userId: 2,
      title: "Effective Rasayanas for Vata imbalance?",
      content: "I'm experiencing dry skin and anxiety, classic Vata imbalance. Which rasayanas or formulations have you found most effective for countering these symptoms?",
      tags: ["Vata Dosha", "Rasayana", "Treatment"],
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      user: {
        id: 2,
        username: "RishiAyur",
        displayName: "RishiAyur"
      }
    },
    {
      id: 2,
      userId: 3,
      title: "Modern preparation of Chyawanprash?",
      content: "I'm looking to prepare authentic Chyawanprash at home but struggling to find some traditional ingredients. What modern substitutes are acceptable while maintaining efficacy?",
      tags: ["Formulations", "Herbs", "Preparation"],
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      user: {
        id: 3,
        username: "AyurPrakash",
        displayName: "AyurPrakash"
      }
    },
    {
      id: 3,
      userId: 4,
      title: "Interpreting classic text on Pitta disorders",
      content: "I'm having trouble interpreting a passage from Charaka Samhita regarding Pitta disorders of the blood. Could anyone help translate the Sanskrit terms in modern medical context?",
      tags: ["Pitta Dosha", "Sanskrit", "Texts"],
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      user: {
        id: 4,
        username: "VaidyaSagar",
        displayName: "VaidyaSagar"
      }
    },
    {
      id: 4,
      userId: 5,
      title: "Seasonal Routine for Tridosha Balance",
      content: "I'm working on a comprehensive seasonal routine to balance all three doshas. What specific practices have you found most effective during the transition between seasons?",
      tags: ["Ritucharya", "Seasonal", "Tridosha"],
      createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      user: {
        id: 5,
        username: "AyurBalance",
        displayName: "Dr. Ayu Balance"
      }
    },
    {
      id: 5,
      userId: 6,
      title: "Growing medicinal herbs at home",
      content: "I've started a small medicinal herb garden at home. Looking for advice on which Ayurvedic herbs are easiest to grow in temperate climates, and basic care instructions.",
      tags: ["Herbs", "Gardening", "Self-sufficiency"],
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      user: {
        id: 6,
        username: "GardenVaidya",
        displayName: "Garden Vaidya"
      }
    },
    {
      id: 6,
      userId: 7,
      title: "Marma points for chronic headaches",
      content: "I've been studying marma therapy for treating chronic tension headaches. Which specific marma points have practitioners found most effective, and what pressure techniques work best?",
      tags: ["Marma", "Therapy", "Headaches"],
      createdAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
      user: {
        id: 7,
        username: "MarmaHealer",
        displayName: "Marma Healer"
      }
    }
  ]);

  // Handle creating a new post
  const handleCreatePost = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to create a post",
        variant: "destructive"
      });
      return;
    }

    if (!newPostTitle || !newPostContent) {
      toast({
        title: "Missing information",
        description: "Please fill in both title and content",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // In a real application, we would call the API
      // const response = await apiRequest("POST", "/api/posts", {
      //   userId: user.id,
      //   title: newPostTitle,
      //   content: newPostContent,
      //   tags: newPostTags.split(",").map(tag => tag.trim())
      // });
      
      // For now, simulate creating a post
      const newPost: Post = {
        id: Date.now(),
        userId: user.id,
        title: newPostTitle,
        content: newPostContent,
        tags: newPostTags.split(",").map(tag => tag.trim()),
        createdAt: new Date(),
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName
        }
      };
      
      setPosts([newPost, ...posts]);
      
      // Reset form and close dialog
      setNewPostTitle("");
      setNewPostContent("");
      setNewPostTags("");
      setIsDialogOpen(false);
      
      toast({
        title: "Post created",
        description: "Your post has been published successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter posts by search query
  const filteredPosts = posts.filter(post => 
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="font-heading text-4xl text-earth mb-4">Ayurvedic Community Forum</h1>
            <p className="text-earth-light max-w-3xl">
              Share your questions, insights, and experiences with fellow Ayurvedic practitioners and enthusiasts
            </p>
          </div>

          <div className="flex flex-col md:flex-row justify-between gap-4 mb-8">
            <div className="relative w-full md:w-2/3">
              <Input
                type="text"
                placeholder="Search discussions..."
                className="bg-cream border-cream-dark pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-earth-light">
                <i className="ri-search-line"></i>
              </div>
            </div>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary-light text-white">
                  <i className="ri-add-line mr-2"></i> New Discussion
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle className="font-heading text-xl text-earth">Start a New Discussion</DialogTitle>
                  <DialogDescription className="text-earth-light">
                    Share your Ayurvedic question or insight with the community
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-earth">Title</label>
                    <Input 
                      placeholder="A clear, specific title for your discussion"
                      className="bg-cream border-cream-dark"
                      value={newPostTitle}
                      onChange={(e) => setNewPostTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-earth">Content</label>
                    <Textarea 
                      placeholder="Describe your question or share your knowledge in detail..."
                      className="bg-cream border-cream-dark min-h-[150px]"
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-earth">Tags</label>
                    <Input 
                      placeholder="Add tags separated by commas (e.g. Vata, Herbs, Treatment)"
                      className="bg-cream border-cream-dark"
                      value={newPostTags}
                      onChange={(e) => setNewPostTags(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    className="bg-primary hover:bg-primary-light text-white"
                    onClick={handleCreatePost}
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <i className="ri-loader-2-line animate-spin mr-2"></i> Posting...
                      </>
                    ) : (
                      <>Post Discussion</>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {/* Filter Categories */}
          <div className="flex flex-wrap gap-2 mb-8">
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("")}
            >
              All Topics
            </Button>
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("Vata")}
            >
              Vata
            </Button>
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("Pitta")}
            >
              Pitta
            </Button>
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("Kapha")}
            >
              Kapha
            </Button>
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("Herbs")}
            >
              Herbs & Formulations
            </Button>
            <Button 
              variant="ghost" 
              className="bg-cream hover:bg-cream-dark text-primary"
              onClick={() => setSearchQuery("Treatment")}
            >
              Treatments
            </Button>
          </div>

          {/* Forum Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <ForumCard key={post.id} post={post} />
              ))
            ) : (
              <div className="col-span-3 text-center py-8">
                <div className="text-4xl text-earth-light mb-4">
                  <i className="ri-file-search-line"></i>
                </div>
                <h3 className="font-heading text-xl text-earth mb-2">No discussions found</h3>
                <p className="text-earth-light">Try a different search term or start a new discussion</p>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
