import { useContext } from "react";
import { UserContext } from "@/App";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import UserSidebar from "@/components/UserSidebar";
import ChatInterface from "@/components/ChatInterface";

export default function Chat() {
  const { user } = useContext(UserContext);
  const [, navigate] = useLocation();

  // If user is not logged in, we should show a welcome message
  const welcomeMessage = user ? `Welcome, ${user.username}!` : "Join to start chatting";

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow">
        <div className="container mx-auto px-4 py-6">
          {/* Welcome Header */}
          <div className="mb-8 text-center">
            <h2 className="font-heading text-3xl text-earth mb-2">
              {user ? (
                <>
                  Welcome, <span className="text-primary font-semibold">{user.username}!</span>
                </>
              ) : (
                "Welcome to Vedic Genie Chat"
              )}
            </h2>
            <p className="text-earth-light">
              {user
                ? "Connect with the Ayurvedic community and share your wisdom"
                : "Login or register to start your Ayurvedic journey"}
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Sidebar - User Profile & Upload */}
            <div className="lg:col-span-1">
              <UserSidebar />
            </div>

            {/* Center Column - Chat Interface */}
            <div className="lg:col-span-2">
              <ChatInterface />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
