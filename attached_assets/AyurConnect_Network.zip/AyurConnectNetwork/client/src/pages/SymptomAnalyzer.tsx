import { useState, useRef, useEffect } from "react";
import { useContext } from "react";
import { UserContext } from "@/App";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WisdomBanner from "@/components/WisdomBanner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { BodyPart, Symptom, UserSymptom, Condition } from "@/lib/types";

// Mock data for body parts and symptoms
const bodyPartsData: BodyPart[] = [
  { id: 1, name: "Head", svgId: "head", description: "Head and brain region" },
  { id: 2, name: "Face", svgId: "face", description: "Face, eyes, ears, nose and mouth" },
  { id: 3, name: "Neck & Throat", svgId: "neck", description: "Neck, throat and thyroid" },
  { id: 4, name: "Chest", svgId: "chest", description: "Chest, heart and lungs" },
  { id: 5, name: "Upper Back", svgId: "upper-back", description: "Upper back and shoulder blades" },
  { id: 6, name: "Abdomen", svgId: "abdomen", description: "Stomach, intestines and digestive organs" },
  { id: 7, name: "Lower Back", svgId: "lower-back", description: "Lower back and spine" },
  { id: 8, name: "Pelvis", svgId: "pelvis", description: "Pelvic region and reproductive organs" },
  { id: 9, name: "Shoulders", svgId: "shoulders", description: "Shoulder joints and muscles" },
  { id: 10, name: "Arms", svgId: "arms", description: "Upper limbs" },
  { id: 11, name: "Hands & Wrists", svgId: "hands", description: "Hands, wrists and fingers" },
  { id: 12, name: "Legs", svgId: "legs", description: "Lower limbs" },
  { id: 13, name: "Knees", svgId: "knees", description: "Knee joints" },
  { id: 14, name: "Feet & Ankles", svgId: "feet", description: "Feet, ankles and toes" },
  { id: 15, name: "Skin", svgId: "skin", description: "Outer covering of the body" },
  { id: 16, name: "Joints", svgId: "joints", description: "All joints of the body" },
];

const symptomsData: Symptom[] = [
  // Head symptoms
  { id: 1, name: "Headache", description: "Pain in the head region", bodyPartId: 1 },
  { id: 2, name: "Dizziness", description: "Feeling of lightheadedness", bodyPartId: 1 },
  { id: 3, name: "Memory issues", description: "Forgetfulness or memory lapses", bodyPartId: 1 },
  { id: 4, name: "Insomnia", description: "Difficulty sleeping", bodyPartId: 1 },

  // Face symptoms
  { id: 5, name: "Blurred vision", description: "Inability to see clearly", bodyPartId: 2 },
  { id: 6, name: "Ear pain", description: "Pain in the ears", bodyPartId: 2 },
  { id: 7, name: "Sinus congestion", description: "Blocked sinuses", bodyPartId: 2 },
  { id: 8, name: "Jaw pain", description: "Pain in the jaw area", bodyPartId: 2 },
  
  // Neck & Throat symptoms
  { id: 9, name: "Sore throat", description: "Pain or irritation in the throat", bodyPartId: 3 },
  { id: 10, name: "Neck stiffness", description: "Rigid or painful neck movement", bodyPartId: 3 },
  { id: 11, name: "Thyroid swelling", description: "Enlargement of the thyroid gland", bodyPartId: 3 },
  
  // Chest symptoms
  { id: 12, name: "Cough", description: "Persistent coughing", bodyPartId: 4 },
  { id: 13, name: "Chest pain", description: "Pain in the chest area", bodyPartId: 4 },
  { id: 14, name: "Shortness of breath", description: "Difficulty breathing", bodyPartId: 4 },
  { id: 15, name: "Heart palpitations", description: "Noticeable heartbeat", bodyPartId: 4 },
  
  // Upper Back symptoms
  { id: 16, name: "Upper back pain", description: "Pain between the shoulder blades", bodyPartId: 5 },
  { id: 17, name: "Shoulder blade tension", description: "Tightness in shoulder blade area", bodyPartId: 5 },
  
  // Abdomen symptoms
  { id: 18, name: "Indigestion", description: "Discomfort during digestion", bodyPartId: 6 },
  { id: 19, name: "Abdominal pain", description: "Pain in the abdominal region", bodyPartId: 6 },
  { id: 20, name: "Bloating", description: "Swollen or distended abdomen", bodyPartId: 6 },
  { id: 21, name: "Nausea", description: "Feeling of wanting to vomit", bodyPartId: 6 },
  
  // Lower Back symptoms
  { id: 22, name: "Lower back pain", description: "Pain in the lumbar region", bodyPartId: 7 },
  { id: 23, name: "Sciatica", description: "Pain radiating down the leg", bodyPartId: 7 },
  
  // Pelvis symptoms
  { id: 24, name: "Pelvic pain", description: "Pain in the pelvic region", bodyPartId: 8 },
  { id: 25, name: "Menstrual irregularities", description: "Abnormal menstrual cycles", bodyPartId: 8 },
  
  // Shoulders symptoms
  { id: 26, name: "Shoulder pain", description: "Pain in the shoulder joints", bodyPartId: 9 },
  { id: 27, name: "Limited range of motion", description: "Restricted shoulder movement", bodyPartId: 9 },
  
  // Arms symptoms
  { id: 28, name: "Arm joint pain", description: "Pain in arm joints", bodyPartId: 10 },
  { id: 29, name: "Arm numbness", description: "Loss of sensation in arms", bodyPartId: 10 },
  { id: 30, name: "Arm weakness", description: "Lack of strength in arms", bodyPartId: 10 },
  
  // Hands & Wrists symptoms
  { id: 31, name: "Wrist pain", description: "Pain in the wrist area", bodyPartId: 11 },
  { id: 32, name: "Finger numbness", description: "Loss of feeling in fingers", bodyPartId: 11 },
  { id: 33, name: "Hand tremors", description: "Shaking or trembling of hands", bodyPartId: 11 },
  
  // Legs symptoms
  { id: 34, name: "Leg muscle pain", description: "Pain in leg muscles", bodyPartId: 12 },
  { id: 35, name: "Leg cramping", description: "Muscle spasms in legs", bodyPartId: 12 },
  { id: 36, name: "Leg swelling", description: "Inflammation in lower limbs", bodyPartId: 12 },
  
  // Knees symptoms
  { id: 37, name: "Knee pain", description: "Pain in knee joints", bodyPartId: 13 },
  { id: 38, name: "Knee stiffness", description: "Rigid or limited knee movement", bodyPartId: 13 },
  
  // Feet & Ankles symptoms
  { id: 39, name: "Foot pain", description: "Pain in the feet", bodyPartId: 14 },
  { id: 40, name: "Ankle swelling", description: "Inflammation around ankles", bodyPartId: 14 },
  { id: 41, name: "Cold feet", description: "Feet feeling unusually cold", bodyPartId: 14 },
  
  // Skin symptoms
  { id: 42, name: "Rash", description: "Skin inflammation", bodyPartId: 15 },
  { id: 43, name: "Itching", description: "Irritation of the skin", bodyPartId: 15 },
  { id: 44, name: "Dry skin", description: "Lack of moisture in skin", bodyPartId: 15 },
  { id: 45, name: "Excessive sweating", description: "Abnormal perspiration", bodyPartId: 15 },
  
  // Joints symptoms
  { id: 46, name: "Multiple joint pain", description: "Pain in several joints", bodyPartId: 16 },
  { id: 47, name: "Joint stiffness", description: "Rigidity in joint movement", bodyPartId: 16 },
  { id: 48, name: "Joint swelling", description: "Inflammation of joints", bodyPartId: 16 },
];

const conditionsData: Condition[] = [
  {
    id: 1,
    name: "Vata Imbalance (Nervous system)",
    description: "Excess vata dosha can lead to nervous system issues and pain.",
    doshaImbalance: "Vata",
    ayurvedicTreatment: "Warm oil massage (abhyanga), warm foods, regular routine, meditation."
  },
  {
    id: 2,
    name: "Pitta Imbalance (Digestive system)",
    description: "Excess pitta dosha leads to inflammation and digestive disorders.",
    doshaImbalance: "Pitta",
    ayurvedicTreatment: "Cooling herbs like coriander and fennel, avoiding spicy foods, aloe vera juice."
  },
  {
    id: 3,
    name: "Kapha Imbalance (Respiratory system)",
    description: "Excess kapha dosha causes congestion and respiratory issues.",
    doshaImbalance: "Kapha",
    ayurvedicTreatment: "Ginger tea, dry brushing, vigorous exercise, avoiding dairy and cold foods."
  },
  {
    id: 4,
    name: "Tridosha Imbalance (Multiple systems)",
    description: "Multiple dosha imbalance affecting several body systems simultaneously.",
    doshaImbalance: "Tridosha",
    ayurvedicTreatment: "Personalized treatment combining diet, lifestyle, and herbal preparations specific to individual constitution."
  }
];

// Schema for user information
const userInfoSchema = z.object({
  age: z.string().min(1, "Age is required"),
  gender: z.string().min(1, "Gender is required"),
  constitution: z.string().optional(),
});

export default function SymptomAnalyzer() {
  const { user } = useContext(UserContext);
  const { toast } = useToast();
  const [selectedBodyPart, setSelectedBodyPart] = useState<BodyPart | null>(null);
  const [relatedSymptoms, setRelatedSymptoms] = useState<Symptom[]>([]);
  const [selectedSymptoms, setSelectedSymptoms] = useState<UserSymptom[]>([]);
  const [activeTab, setActiveTab] = useState("info");
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [matchedConditions, setMatchedConditions] = useState<Condition[]>([]);
  const [topMatch, setTopMatch] = useState<Condition | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  
  // Form for user information
  const form = useForm<z.infer<typeof userInfoSchema>>({
    resolver: zodResolver(userInfoSchema),
    defaultValues: {
      age: "",
      gender: "",
      constitution: "",
    },
  });

  // Handle body part selection
  const handleBodyPartClick = (bodyPart: BodyPart) => {
    setSelectedBodyPart(bodyPart);
    const symptoms = symptomsData.filter(symptom => symptom.bodyPartId === bodyPart.id);
    setRelatedSymptoms(symptoms);
  };

  // Add symptom to selected list
  const addSymptom = (symptom: Symptom) => {
    // Check if already added
    if (selectedSymptoms.some(s => s.symptomId === symptom.id)) {
      toast({
        title: "Symptom already added",
        description: `${symptom.name} is already in your symptom list`,
        variant: "destructive",
      });
      return;
    }
    
    // Add to selected symptoms
    const userSymptom: UserSymptom = {
      id: `user-symptom-${Date.now()}`,
      symptomId: symptom.id,
      name: symptom.name
    };
    
    setSelectedSymptoms([...selectedSymptoms, userSymptom]);
    
    toast({
      title: "Symptom added",
      description: `Added ${symptom.name} to your symptoms`,
    });
  };

  // Remove symptom from selected list
  const removeSymptom = (symptomId: string) => {
    setSelectedSymptoms(selectedSymptoms.filter(s => s.id !== symptomId));
  };

  // Process symptoms and analyze using Gemini AI
  const analyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) {
      toast({
        title: "No symptoms selected",
        description: "Please select at least one symptom to analyze",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // Show loading state
      toast({
        title: "Analyzing symptoms",
        description: "Please wait while we analyze your symptoms...",
      });
      
      // Get the form values for additional context
      const formValues = form.getValues();
      
      // Get symptom names for the analysis
      const symptomDescriptions = selectedSymptoms.map(s => {
        const fullSymptom = symptomsData.find(sd => sd.id === s.symptomId);
        const bodyPart = bodyPartsData.find(bp => bp.id === fullSymptom?.bodyPartId);
        return `${s.name} (${bodyPart?.name})`;
      });
      
      // Call the AI analysis endpoint
      const response = await fetch('/api/ai/analyze-symptoms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: symptomDescriptions,
          userInfo: {
            age: formValues.age,
            gender: formValues.gender,
            constitution: formValues.constitution,
          }
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze symptoms');
      }
      
      const data = await response.json();
      
      // Extract information from AI analysis
      const aiAnalysis = data.analysis;
      
      // Find the most likely condition based on the analysis
      // This is a fallback in case AI doesn't return structured data
      let mainCondition = conditionsData.find(c => c.id === 1); // Default to vata
      
      // Simple heuristic for dosha determination
      if (aiAnalysis.toLowerCase().includes('pitta') && aiAnalysis.toLowerCase().includes('imbalance')) {
        mainCondition = conditionsData.find(c => c.id === 2);
      } else if (aiAnalysis.toLowerCase().includes('kapha') && aiAnalysis.toLowerCase().includes('imbalance')) {
        mainCondition = conditionsData.find(c => c.id === 3);
      } else if (aiAnalysis.toLowerCase().includes('tridosha') || 
                (aiAnalysis.toLowerCase().includes('vata') && 
                 aiAnalysis.toLowerCase().includes('pitta') && 
                 aiAnalysis.toLowerCase().includes('kapha'))) {
        mainCondition = conditionsData.find(c => c.id === 4);
      }
      
      // Create a custom top match condition from AI analysis
      const topMatchCondition: Condition = {
        id: 999, // Custom ID
        name: mainCondition?.name || "Potential Dosha Imbalance",
        description: "Based on your symptoms, the AI analysis suggests potential imbalances.",
        doshaImbalance: mainCondition?.doshaImbalance || "Mixed",
        ayurvedicTreatment: aiAnalysis,
      };
      
      // Set other potential conditions
      let otherConditions = conditionsData
        .filter(c => c.id !== mainCondition?.id)
        .slice(0, 2); // Just show a couple alternatives
        
      setMatchedConditions([...otherConditions, topMatchCondition]);
      setTopMatch(topMatchCondition);
      setAnalysisComplete(true);
      setActiveTab("results");
      
      toast({
        title: "Analysis complete",
        description: "Your symptoms have been analyzed according to Ayurvedic principles.",
      });
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      
      // Fallback to the simple analysis if AI fails
      const userSymptomIds = selectedSymptoms.map(s => s.symptomId);
      
      // Get body parts involved
      const involvedBodyParts = new Set<number>();
      userSymptomIds.forEach(id => {
        const symptom = symptomsData.find(s => s.id === id);
        if (symptom) {
          involvedBodyParts.add(symptom.bodyPartId);
        }
      });
      
      // Match conditions based on dosha imbalance
      let matched: Condition[] = [];
      
      // Pitta symptoms (abdomen, skin inflammations)
      if (involvedBodyParts.has(3) || (involvedBodyParts.has(6) && userSymptomIds.includes(12))) {
        matched.push(conditionsData.find(c => c.id === 2)!);
      }
      
      // Vata symptoms (headache, joint pain, numbness)
      if (involvedBodyParts.has(1) || userSymptomIds.includes(8) || userSymptomIds.includes(10) || userSymptomIds.includes(9)) {
        matched.push(conditionsData.find(c => c.id === 1)!);
      }
      
      // Kapha symptoms (respiratory, swelling)
      if (involvedBodyParts.has(2) || userSymptomIds.includes(11)) {
        matched.push(conditionsData.find(c => c.id === 3)!);
      }
      
      // If multiple body systems are involved, suggest tridosha imbalance
      if (involvedBodyParts.size >= 3) {
        matched.push(conditionsData.find(c => c.id === 4)!);
      }
      
      // If no matches were found, default to the first condition
      if (matched.length === 0) {
        matched = [conditionsData[0]];
      }
      
      const topMatchCondition = matched[0];
      
      setMatchedConditions(matched);
      setTopMatch(topMatchCondition);
      setAnalysisComplete(true);
      setActiveTab("results");
      
      toast({
        title: "Analysis complete",
        description: "Your symptoms have been analyzed according to Ayurvedic principles.",
        variant: "default",
      });
    }
  };

  const onSubmit = (values: z.infer<typeof userInfoSchema>) => {
    console.log(values);
    // Move to symptoms tab after submitting info
    setActiveTab("symptoms");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <WisdomBanner />

      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <h1 className="font-heading text-4xl text-earth mb-2">Ayurvedic Symptom Analyzer</h1>
          <p className="text-earth-light mb-8 max-w-3xl">
            Identify possible dosha imbalances and receive Ayurvedic treatment recommendations based on your symptoms
          </p>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 w-full max-w-xl mx-auto mb-8">
              <TabsTrigger value="info" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                <i className="ri-information-line mr-2"></i> Info
              </TabsTrigger>
              <TabsTrigger value="symptoms" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                <i className="ri-heart-pulse-line mr-2"></i> Symptoms
              </TabsTrigger>
              <TabsTrigger value="results" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                <i className="ri-file-list-3-line mr-2"></i> Results
              </TabsTrigger>
            </TabsList>

            {/* User Info Tab */}
            <TabsContent value="info">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card className="bg-white rounded-xl natural-shadow">
                  <CardHeader>
                    <CardTitle className="font-heading text-2xl text-earth">Personal Information</CardTitle>
                    <CardDescription className="text-earth-light">
                      Please provide basic information to help with the analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="age"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-earth">Age</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="Enter your age" 
                                  className="bg-cream border-cream-dark" 
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="gender"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-earth">Gender</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="bg-cream border-cream-dark">
                                    <SelectValue placeholder="Select your gender" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="male">Male</SelectItem>
                                  <SelectItem value="female">Female</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="constitution"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-earth">Dosha Constitution (if known)</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="bg-cream border-cream-dark">
                                    <SelectValue placeholder="Select your dosha type (optional)" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="vata">Vata</SelectItem>
                                  <SelectItem value="pitta">Pitta</SelectItem>
                                  <SelectItem value="kapha">Kapha</SelectItem>
                                  <SelectItem value="vata-pitta">Vata-Pitta</SelectItem>
                                  <SelectItem value="pitta-kapha">Pitta-Kapha</SelectItem>
                                  <SelectItem value="vata-kapha">Vata-Kapha</SelectItem>
                                  <SelectItem value="vata-pitta-kapha">Tridosha (balanced)</SelectItem>
                                  <SelectItem value="unknown">Not Sure</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full bg-primary hover:bg-primary-light text-white"
                        >
                          Continue to Symptoms
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                <div>
                  <Card className="bg-white rounded-xl natural-shadow mb-6">
                    <CardHeader>
                      <CardTitle className="font-heading text-2xl text-earth">Why This Matters</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-earth-light mb-4">
                        In Ayurveda, your age, gender, and constitution (prakruti) are essential 
                        factors in determining the most effective treatment approach.
                      </p>
                      <ul className="space-y-3 text-earth-light">
                        <li className="flex items-start">
                          <span className="text-primary mr-2"><i className="ri-checkbox-circle-line"></i></span>
                          <span>Your <strong>age</strong> influences your dosha balance, with different doshas predominating at different life stages.</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2"><i className="ri-checkbox-circle-line"></i></span>
                          <span>Your <strong>gender</strong> affects how doshas manifest and which treatments may be most appropriate.</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2"><i className="ri-checkbox-circle-line"></i></span>
                          <span>Your <strong>constitution</strong> (prakruti) is your natural dosha balance, which helps determine how imbalances might present in your body.</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                  
                  <div className="text-center p-4 bg-cream-dark rounded-xl natural-shadow">
                    <p className="font-script text-accent text-2xl">
                      "Understanding your unique constitution is the first step toward balanced health"
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Symptoms Tab */}
            <TabsContent value="symptoms">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Body Part Selection */}
                <Card className="bg-white rounded-xl natural-shadow lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="font-heading text-2xl text-earth">Select Body Part</CardTitle>
                    <CardDescription className="text-earth-light">
                      Click on a body region to show related symptoms
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col-reverse lg:flex-row">
                      <div className="flex flex-wrap gap-3 mt-4 lg:mt-0 lg:mr-6 lg:flex-col">
                        {bodyPartsData.map(part => (
                          <Button
                            key={part.id}
                            variant={selectedBodyPart?.id === part.id ? "default" : "outline"}
                            className={`${selectedBodyPart?.id === part.id ? 'bg-primary text-white' : 'border-primary text-primary'}`}
                            onClick={() => handleBodyPartClick(part)}
                          >
                            {part.name}
                          </Button>
                        ))}
                      </div>
                      
                      {/* Human Figure SVG */}
                      <div className="flex-grow flex items-center justify-center p-4">
                        <div className="relative max-w-[300px] mx-auto natural-shadow-lg">
                          <svg 
                            viewBox="0 0 300 600" 
                            className="w-full h-auto"
                            ref={svgRef}
                          >
                            {/* Base Body Shape */}
                            <defs>
                              <linearGradient id="body-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" style={{ stopColor: '#d9c8b4', stopOpacity: 0.8 }} />
                                <stop offset="50%" style={{ stopColor: '#e8dac9', stopOpacity: 1 }} />
                                <stop offset="100%" style={{ stopColor: '#d9c8b4', stopOpacity: 0.8 }} />
                              </linearGradient>
                            </defs>
                            
                            {/* Body Outline - for 3D effect */}
                            <path d="M150,30 
                                   C120,30 90,45 90,80 
                                   C90,100 90,120 80,150
                                   C70,180 60,200 60,250
                                   C60,300 70,350 90,400
                                   C110,450 120,500 130,550
                                   L170,550
                                   C180,500 190,450 210,400
                                   C230,350 240,300 240,250
                                   C240,200 230,180 220,150
                                   C210,120 210,100 210,80
                                   C210,45 180,30 150,30Z" 
                                  fill="url(#body-gradient)" 
                                  stroke="#d0c0a8" 
                                  strokeWidth="2" />

                            {/* Head */}
                            <ellipse 
                              cx="150" cy="60" rx="35" ry="45" 
                              className={`${selectedBodyPart?.svgId === 'head' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'head')!)}
                            />
                            
                            {/* Face */}
                            <ellipse 
                              cx="150" cy="75" rx="25" ry="20" 
                              className={`${selectedBodyPart?.svgId === 'face' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'face')!)}
                            />
                            
                            {/* Neck & Throat */}
                            <rect 
                              x="135" y="95" width="30" height="20" rx="5"
                              className={`${selectedBodyPart?.svgId === 'neck' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'neck')!)}
                            />
                            
                            {/* Shoulders */}
                            <path d="M110,120 L80,130 L85,145 L110,140 Z" 
                                className={`${selectedBodyPart?.svgId === 'shoulders' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'shoulders')!)}
                            />
                            <path d="M190,120 L220,130 L215,145 L190,140 Z" 
                                className={`${selectedBodyPart?.svgId === 'shoulders' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'shoulders')!)}
                            />
                            
                            {/* Chest */}
                            <path d="M110,120 L190,120 L190,170 L110,170 Z" 
                                className={`${selectedBodyPart?.svgId === 'chest' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'chest')!)}
                            />
                            
                            {/* Upper Back */}
                            <ellipse 
                              cx="150" cy="140" rx="25" ry="30" 
                              className={`${selectedBodyPart?.svgId === 'upper-back' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'upper-back')!)}
                            />
                            
                            {/* Abdomen */}
                            <path d="M110,170 L190,170 L180,240 L120,240 Z" 
                                className={`${selectedBodyPart?.svgId === 'abdomen' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'abdomen')!)}
                            />
                            
                            {/* Lower Back */}
                            <ellipse 
                              cx="150" cy="200" rx="20" ry="30" 
                              className={`${selectedBodyPart?.svgId === 'lower-back' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'lower-back')!)}
                            />
                            
                            {/* Pelvis */}
                            <path d="M120,240 L180,240 L175,270 L125,270 Z" 
                                className={`${selectedBodyPart?.svgId === 'pelvis' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'pelvis')!)}
                            />
                            
                            {/* Arms */}
                            <path d="M80,130 L60,200 L75,210 L90,150 Z" 
                                className={`${selectedBodyPart?.svgId === 'arms' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'arms')!)}
                            />
                            <path d="M220,130 L240,200 L225,210 L210,150 Z" 
                                className={`${selectedBodyPart?.svgId === 'arms' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'arms')!)}
                            />
                            
                            {/* Hands & Wrists */}
                            <circle 
                              cx="60" cy="215" r="15" 
                              className={`${selectedBodyPart?.svgId === 'hands' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'hands')!)}
                            />
                            <circle 
                              cx="240" cy="215" r="15" 
                              className={`${selectedBodyPart?.svgId === 'hands' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'hands')!)}
                            />
                            
                            {/* Legs */}
                            <path d="M125,270 L110,400 L130,400 L140,270 Z" 
                                className={`${selectedBodyPart?.svgId === 'legs' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'legs')!)}
                            />
                            <path d="M175,270 L190,400 L170,400 L160,270 Z" 
                                className={`${selectedBodyPart?.svgId === 'legs' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'legs')!)}
                            />
                            
                            {/* Knees */}
                            <circle 
                              cx="120" cy="350" r="15" 
                              className={`${selectedBodyPart?.svgId === 'knees' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'knees')!)}
                            />
                            <circle 
                              cx="180" cy="350" r="15" 
                              className={`${selectedBodyPart?.svgId === 'knees' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'knees')!)}
                            />
                            
                            {/* Feet & Ankles */}
                            <path d="M110,400 L90,430 L130,430 L130,400 Z" 
                                className={`${selectedBodyPart?.svgId === 'feet' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'feet')!)}
                            />
                            <path d="M190,400 L210,430 L170,430 L170,400 Z" 
                                className={`${selectedBodyPart?.svgId === 'feet' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                                onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'feet')!)}
                            />
                            
                            {/* Joints */}
                            <circle 
                              cx="80" cy="130" r="5" 
                              className={`${selectedBodyPart?.svgId === 'joints' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'joints')!)}
                            />
                            <circle 
                              cx="220" cy="130" r="5" 
                              className={`${selectedBodyPart?.svgId === 'joints' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'joints')!)}
                            />
                            <circle 
                              cx="125" cy="270" r="5" 
                              className={`${selectedBodyPart?.svgId === 'joints' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'joints')!)}
                            />
                            <circle 
                              cx="175" cy="270" r="5" 
                              className={`${selectedBodyPart?.svgId === 'joints' ? 'fill-primary opacity-60 stroke-primary stroke-2' : 'fill-transparent stroke-earth-light stroke-1'} cursor-pointer transition-all hover:fill-primary hover:opacity-40`}
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'joints')!)}
                            />
                          </svg>
                          
                          {/* Add labels for better UX */}
                          <div className="absolute top-0 left-0 w-full h-full pointer-events-none text-xs text-earth-dark">
                            <div style={{ position: 'absolute', top: '60px', left: '50%', transform: 'translateX(-50%)' }}>Head</div>
                            <div style={{ position: 'absolute', top: '150px', left: '50%', transform: 'translateX(-50%)' }}>Chest</div>
                            <div style={{ position: 'absolute', top: '205px', left: '50%', transform: 'translateX(-50%)' }}>Abdomen</div>
                            <div style={{ position: 'absolute', top: '350px', left: '50%', transform: 'translateX(-50%)' }}>Legs</div>
                          </div>
                          
                          {/* Special Case Buttons */}
                          <div className="absolute top-0 right-0 space-y-2">
                            <Button
                              variant="outline"
                              className="text-xs px-2 py-1 h-auto border-primary text-primary hover:bg-primary hover:text-white"
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'skin')!)}
                            >
                              Skin
                            </Button>
                            <Button
                              variant="outline"
                              className="text-xs px-2 py-1 h-auto border-primary text-primary hover:bg-primary hover:text-white"
                              onClick={() => handleBodyPartClick(bodyPartsData.find(p => p.svgId === 'joints')!)}
                            >
                              All Joints
                            </Button>
                          </div>
                        </div>
                      </div>
                      
                      {/* Related Symptoms List */}
                      <div className="lg:w-1/3 mt-6 lg:mt-0">
                        {selectedBodyPart ? (
                          <div>
                            <h3 className="font-heading text-xl text-earth mb-2">{selectedBodyPart.name} Symptoms</h3>
                            <p className="text-earth-light text-sm mb-4">{selectedBodyPart.description}</p>
                            
                            <ul className="space-y-2">
                              {relatedSymptoms.length > 0 ? (
                                relatedSymptoms.map(symptom => (
                                  <li key={symptom.id} className="bg-cream rounded-lg p-3">
                                    <p className="text-earth font-medium">{symptom.name}</p>
                                    {symptom.description && (
                                      <p className="text-xs text-earth-light mb-2">{symptom.description}</p>
                                    )}
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="text-primary hover:text-primary-dark hover:bg-cream-dark w-full justify-start"
                                      onClick={() => addSymptom(symptom)}
                                    >
                                      <i className="ri-add-line mr-1"></i> Add symptom
                                    </Button>
                                  </li>
                                ))
                              ) : (
                                <li className="text-earth-light italic">No specific symptoms available for this region</li>
                              )}
                            </ul>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center h-full">
                            <i className="ri-arrow-left-line text-3xl text-earth-light mb-2"></i>
                            <p className="text-earth-light text-center">Please select a body part to see related symptoms</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Selected Symptoms */}
                <Card className="bg-white rounded-xl natural-shadow">
                  <CardHeader>
                    <CardTitle className="font-heading text-2xl text-earth">My Symptoms</CardTitle>
                    <CardDescription className="text-earth-light">
                      Your selected symptoms for analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {selectedSymptoms.length > 0 ? (
                      <div className="space-y-4">
                        <ul className="min-h-[200px] space-y-2">
                          {selectedSymptoms.map(symptom => (
                            <li key={symptom.id} className="flex justify-between items-center">
                              <span className="text-earth">{symptom.name}</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-accent hover:text-accent-dark hover:bg-cream-dark h-8 w-8 p-0"
                                onClick={() => removeSymptom(symptom.id)}
                              >
                                <i className="ri-close-line"></i>
                              </Button>
                            </li>
                          ))}
                        </ul>
                        
                        <Separator />
                        
                        <Button 
                          className="w-full bg-primary hover:bg-primary-light"
                          onClick={analyzeSymptoms}
                        >
                          <i className="ri-search-line mr-2"></i> Analyze Symptoms
                        </Button>
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <i className="ri-file-list-3-line text-3xl text-earth-light mb-2"></i>
                        <p className="text-earth-light">No symptoms added yet</p>
                        <p className="text-earth-light text-sm mt-2">Click on a body part and add symptoms from the list</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Results Tab */}
            <TabsContent value="results">
              {analysisComplete ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <Card className="bg-white rounded-xl natural-shadow overflow-hidden">
                    <CardHeader className="bg-primary text-white">
                      <CardTitle className="font-heading text-2xl flex items-center">
                        <i className="ri-mental-health-line mr-2"></i> Analysis Results
                      </CardTitle>
                      <CardDescription className="text-primary-foreground opacity-90">
                        Based on your symptoms, we've identified possible Ayurvedic imbalances
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="mb-8">
                        <h3 className="font-heading text-xl text-earth mb-4 flex items-center">
                          <i className="ri-star-line mr-2 text-secondary"></i>Primary Condition
                        </h3>
                        <div className="bg-cream rounded-lg p-6 shadow-inner">
                          <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3 mb-4">
                            <h4 className="font-heading text-xl text-primary">{topMatch?.name}</h4>
                            <Badge className="bg-secondary text-secondary-foreground text-sm px-3 py-1">
                              {topMatch?.doshaImbalance} Dosha
                            </Badge>
                          </div>
                          
                          <div className="mb-6 p-3 bg-white bg-opacity-50 rounded-md">
                            <p className="text-earth font-medium mb-1">Description:</p>
                            <p className="text-earth-light">{topMatch?.description}</p>
                          </div>
                          
                          {/* Dosha Balance Visualization */}
                          <div className="mb-6">
                            <p className="text-earth font-medium mb-2">Dosha Balance:</p>
                            <div className="flex items-center gap-1 mb-4">
                              <div className={`h-4 rounded-l-full ${topMatch?.doshaImbalance === 'Vata' || topMatch?.doshaImbalance === 'Tridosha' ? 'bg-secondary' : 'bg-cream-dark'} flex-grow relative`}>
                                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-medium">Vata</span>
                              </div>
                              <div className={`h-4 ${topMatch?.doshaImbalance === 'Pitta' || topMatch?.doshaImbalance === 'Tridosha' ? 'bg-secondary' : 'bg-cream-dark'} flex-grow relative`}>
                                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-medium">Pitta</span>
                              </div>
                              <div className={`h-4 rounded-r-full ${topMatch?.doshaImbalance === 'Kapha' || topMatch?.doshaImbalance === 'Tridosha' ? 'bg-secondary' : 'bg-cream-dark'} flex-grow relative`}>
                                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-medium">Kapha</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="border-l-4 border-secondary pl-4 bg-white bg-opacity-50 p-4 rounded-r-md">
                            <h5 className="font-medium text-earth mb-2 flex items-center">
                              <i className="ri-medicine-bottle-line mr-2 text-secondary"></i>
                              Ayurvedic Treatment Approach:
                            </h5>
                            <p className="text-earth-light whitespace-pre-line">{topMatch?.ayurvedicTreatment}</p>
                          </div>
                        </div>
                      </div>
                      
                      {matchedConditions.length > 1 && (
                        <div>
                          <h3 className="font-heading text-xl text-earth mb-4 flex items-center">
                            <i className="ri-scales-3-line mr-2 text-accent"></i>
                            Other Possible Imbalances
                          </h3>
                          <div className="space-y-4">
                            {matchedConditions.filter(c => c.id !== topMatch?.id).map(condition => (
                              <div key={condition.id} className="bg-cream rounded-lg p-4 shadow-inner">
                                <div className="flex justify-between items-center mb-3">
                                  <h4 className="font-medium text-earth">{condition.name}</h4>
                                  <Badge variant="outline" className="border-accent text-accent">
                                    {condition.doshaImbalance}
                                  </Badge>
                                </div>
                                <p className="text-earth-light text-sm">{condition.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <div className="space-y-6">
                    <Card className="bg-white rounded-xl natural-shadow overflow-hidden">
                      <CardHeader className="bg-cream">
                        <CardTitle className="font-heading text-2xl text-earth flex items-center">
                          <i className="ri-health-book-line mr-2 text-primary"></i>Your Symptoms
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                          {selectedSymptoms.map(symptom => {
                            // Find the body part this symptom belongs to
                            const symptomData = symptomsData.find(s => s.id === symptom.symptomId);
                            const bodyPart = bodyPartsData.find(b => b.id === symptomData?.bodyPartId);
                            
                            return (
                              <div key={symptom.id} className="bg-cream-light p-3 rounded-md border-l-4 border-primary">
                                <p className="font-medium text-earth">{symptom.name}</p>
                                {bodyPart && (
                                  <p className="text-xs text-earth-light mt-1">
                                    <i className="ri-pin-distance-line mr-1"></i>{bodyPart.name}
                                  </p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                        
                        {/* Symptom Distribution Chart */}
                        <div className="mt-6 p-4 bg-cream rounded-lg">
                          <h4 className="text-earth font-medium mb-3">Symptom Distribution by Body Area</h4>
                          <div className="space-y-2">
                            {/* Count symptoms by body part and show distribution */}
                            {Array.from(new Set(selectedSymptoms.map(s => {
                              const symptomData = symptomsData.find(sd => sd.id === s.symptomId);
                              return symptomData?.bodyPartId;
                            }))).map(bodyPartId => {
                              if (!bodyPartId) return null;
                              
                              const count = selectedSymptoms.filter(s => {
                                const symptomData = symptomsData.find(sd => sd.id === s.symptomId);
                                return symptomData?.bodyPartId === bodyPartId;
                              }).length;
                              
                              const bodyPart = bodyPartsData.find(b => b.id === bodyPartId);
                              const percentage = Math.round((count / selectedSymptoms.length) * 100);
                              
                              if (!bodyPart) return null;
                              
                              return (
                                <div key={bodyPartId} className="w-full">
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-earth">{bodyPart.name}</span>
                                    <span className="text-earth-light">{count} symptom{count !== 1 ? 's' : ''}</span>
                                  </div>
                                  <div className="w-full bg-cream-dark rounded-full h-2">
                                    <div 
                                      className="bg-primary h-2 rounded-full" 
                                      style={{ width: `${percentage}%` }}
                                    ></div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-white rounded-xl natural-shadow">
                      <CardHeader>
                        <CardTitle className="font-heading text-2xl text-earth flex items-center">
                          <i className="ri-road-map-line mr-2 text-secondary"></i>Next Steps
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-4">
                          <li className="flex items-start bg-cream-light p-3 rounded-md">
                            <span className="text-secondary mr-3 mt-1 text-lg"><i className="ri-user-heart-line"></i></span>
                            <div>
                              <p className="text-earth font-medium">Consult with an Ayurvedic practitioner</p>
                              <p className="text-earth-light text-sm">For personalized diagnosis and treatment plan</p>
                            </div>
                          </li>
                          <li className="flex items-start bg-cream-light p-3 rounded-md">
                            <span className="text-secondary mr-3 mt-1 text-lg"><i className="ri-seedling-line"></i></span>
                            <div>
                              <p className="text-earth font-medium">Follow the treatment guidelines</p>
                              <p className="text-earth-light text-sm">Implement the suggested dietary and lifestyle changes</p>
                            </div>
                          </li>
                          <li className="flex items-start bg-cream-light p-3 rounded-md">
                            <span className="text-secondary mr-3 mt-1 text-lg"><i className="ri-calendar-check-line"></i></span>
                            <div>
                              <p className="text-earth font-medium">Track your symptoms</p>
                              <p className="text-earth-light text-sm">Monitor changes as you implement Ayurvedic practices</p>
                            </div>
                          </li>
                        </ul>
                        
                        <div className="mt-6">
                          <Button 
                            variant="outline" 
                            className="w-full border-primary text-primary hover:bg-primary hover:text-white"
                            onClick={() => {
                              setSelectedSymptoms([]);
                              setAnalysisComplete(false);
                              setActiveTab("info");
                            }}
                          >
                            <i className="ri-refresh-line mr-2"></i> Start New Analysis
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-cream-dark rounded-xl natural-shadow p-6">
                      <p className="font-script text-accent text-center text-2xl mb-4">
                        "True healing begins with understanding your unique nature"
                      </p>
                      
                      <div className="space-y-4 text-earth-light text-sm p-4 bg-white bg-opacity-30 rounded-lg">
                        <div className="flex items-start">
                          <div className="mr-3 text-accent text-xl"><i className="ri-information-line"></i></div>
                          <p>This analysis is based on Ayurvedic principles and is meant for educational purposes only.</p>
                        </div>
                        
                        <div className="flex items-start">
                          <div className="mr-3 text-accent text-xl"><i className="ri-medicine-bottle-line"></i></div>
                          <p>Consult with a qualified Ayurvedic practitioner before starting any treatment regimen.</p>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              ) : (
                <div className="text-center py-20">
                  <i className="ri-file-search-line text-5xl text-earth-light mb-4"></i>
                  <h3 className="font-heading text-2xl text-earth mb-2">No Analysis Results Yet</h3>
                  <p className="text-earth-light max-w-md mx-auto mb-6">
                    Please complete the information and symptom selection process to receive your personalized Ayurvedic analysis
                  </p>
                  <Button 
                    className="bg-primary hover:bg-primary-light"
                    onClick={() => setActiveTab("info")}
                  >
                    Start Analysis
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}