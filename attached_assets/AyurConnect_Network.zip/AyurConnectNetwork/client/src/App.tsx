import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Chat from "@/pages/Chat";
import Forum from "@/pages/Forum";
import About from "@/pages/About";
import SymptomAnalyzer from "@/pages/SymptomAnalyzer";
import { useState, createContext, useEffect } from "react";
import { User } from "./lib/types";

// Create a context for authenticated user
export const UserContext = createContext<{
  user: User | null;
  setUser: (user: User | null) => void;
}>({
  user: null,
  setUser: () => {},
});

function AppRouter() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/chat" component={Chat} />
      <Route path="/forum" component={Forum} />
      <Route path="/about" component={About} />
      <Route path="/symptom-analyzer" component={SymptomAnalyzer} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const checkLoggedInUser = async () => {
      try {
        const response = await fetch("/api/user/current", {
          credentials: "include",
        });

        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
          console.log("✅ User authenticated:", userData);
        } else {
          console.warn("⚠️ Not authenticated or session expired");
          setUser(null);
        }
      } catch (error) {
        console.error("❌ Error checking logged in user:", error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkLoggedInUser();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <UserContext.Provider value={{ user, setUser }}>
        <TooltipProvider>
          <Toaster />
          {loading ? (
            <div className="flex items-center justify-center min-h-screen bg-cream">
              <div className="text-primary text-3xl">
                <i className="ri-loader-2-line animate-spin"></i>
              </div>
            </div>
          ) : (
            <AppRouter />
          )}
        </TooltipProvider>
      </UserContext.Provider>
    </QueryClientProvider>
  );
}

export default App;
