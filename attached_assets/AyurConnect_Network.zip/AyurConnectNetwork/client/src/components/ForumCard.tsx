import { Post } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";

interface ForumCardProps {
  post: Post;
}

export default function ForumCard({ post }: ForumCardProps) {
  // Get the first letter of username for avatar
  const userInitial = post.user?.username.charAt(0).toUpperCase() || "U";
  
  // Function to determine background color based on username
  const getUserAvatarColor = (username: string) => {
    const colors = ["bg-accent", "bg-secondary", "bg-primary"];
    const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return colors[hash % colors.length];
  };
  
  const avatarClass = getUserAvatarColor(post.user?.username || "");
  
  return (
    <Card className="bg-white rounded-xl natural-shadow overflow-hidden hover:shadow-lg transition-all">
      <CardContent className="p-5">
        <div className="flex items-start">
          {/* User Avatar */}
          <div className={`w-10 h-10 rounded-full ${avatarClass} flex items-center justify-center flex-shrink-0`}>
            <span className="text-white text-sm font-semibold">{userInitial}</span>
          </div>

          {/* Question Content */}
          <div className="ml-3 flex-grow">
            <h3 className="font-heading text-lg text-earth font-semibold leading-tight">
              {post.title}
            </h3>
            <p className="text-xs text-earth-light mt-1 flex items-center">
              <span>{post.user?.displayName || post.user?.username}</span>
              <span className="mx-1">•</span>
              <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
            </p>
          </div>
        </div>

        <p className="mt-3 text-earth text-sm line-clamp-3">{post.content}</p>

        {/* Tags */}
        <div className="mt-4 flex flex-wrap">
          {post.tags.map((tag, index) => (
            <span 
              key={index} 
              className="text-xs bg-cream rounded-full px-2 py-1 mr-2 mb-1 text-primary"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Stats - These would be real data in a full implementation */}
        <div className="mt-4 flex text-earth-light text-sm">
          <div className="flex items-center mr-4">
            <i className="ri-chat-1-line mr-1"></i>
            <span>{Math.floor(Math.random() * 50)} replies</span>
          </div>
          <div className="flex items-center">
            <i className="ri-heart-line mr-1"></i>
            <span>{Math.floor(Math.random() * 40)} likes</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
