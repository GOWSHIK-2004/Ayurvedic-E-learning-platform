import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";

export default function Navbar() {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const navItems = [
    { name: "Home", path: "/", icon: "ri-home-4-line" },
    { name: "Chat", path: "/chat", icon: "ri-chat-1-line" },
    { name: "Forum", path: "/forum", icon: "ri-discuss-line" },
    { name: "Symptom Analyzer", path: "/symptom-analyzer", icon: "ri-heart-pulse-line" },
    { name: "About", path: "/about", icon: "ri-information-line" },
  ];

  return (
    <header className="bg-primary shadow-md relative z-10">
      <div className="container mx-auto px-4 py-2">
        <div className="flex justify-between items-center">
          {/* Logo and Title */}
          <div className="flex items-center">
            <div className="mr-2 text-secondary-light text-xl">
              <i className="ri-plant-line"></i>
            </div>
            <h1 className="text-primary-foreground font-heading text-2xl font-semibold">
              Vedic Genie
            </h1>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex space-x-1">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <a
                  className={`px-3 py-2 rounded-md ${
                    location === item.path
                      ? "bg-primary-light text-primary-foreground"
                      : "text-primary-foreground hover:bg-primary-light"
                  } transition-all flex items-center`}
                >
                  <i className={`${item.icon} mr-1`}></i> {item.name}
                </a>
              </Link>
            ))}
          </nav>

          {/* Auth Buttons / User Menu */}
          <div className="flex items-center">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="p-0">
                    <div className="flex items-center space-x-2">
                      <span className="text-primary-foreground text-sm hidden sm:inline-block">
                        {user?.firstName || user?.email?.split('@')[0]}
                      </span>
                      <Avatar className="h-8 w-8 bg-secondary text-primary">
                        <AvatarFallback>
                          {user?.firstName?.charAt(0).toUpperCase() || 
                           user?.email?.charAt(0).toUpperCase() || 'U'}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem>Your Profile</DropdownMenuItem>
                  <DropdownMenuItem>Settings</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-accent"
                    onClick={handleLogout}
                  >
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex space-x-2">
                <Button
                  variant="ghost"
                  className="text-primary-foreground hover:bg-primary-light"
                  onClick={() => window.location.href = "/api/login"}
                >
                  Login
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-primary-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden mt-2 pb-2 ${mobileMenuOpen ? "block" : "hidden"}`}
        >
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a
                className={`block px-3 py-2 rounded-md ${
                  location === item.path
                    ? "bg-primary-light text-primary-foreground"
                    : "text-primary-foreground hover:bg-primary-light"
                } transition-all`}
                onClick={() => setMobileMenuOpen(false)}
              >
                <i className={`${item.icon} mr-1`}></i> {item.name}
              </a>
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
}
