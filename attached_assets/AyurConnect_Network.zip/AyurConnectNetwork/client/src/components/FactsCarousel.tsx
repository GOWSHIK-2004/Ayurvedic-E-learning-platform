import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { AyurvedicFact } from "@/lib/types";

// Mock Ayurvedic Facts
const facts: AyurvedicFact[] = [
  {
    id: 1,
    title: "The Five Elements",
    content: "Ayurveda recognizes that all living and non-living things in the universe are made up of the five elements (Panchamahabhutas): Space, Air, Fire, Water, and Earth. These elements combine to form the three doshas (Vata, Pitta, and Kapha) that determine your body constitution.",
    imageUrl: "https://pixabay.com/get/g6e6d2f9f08f989bb8458e865e0a61b2fc55dd56ac5ac32a3a0affe4a4a4f91e09e9ede8af9ad84f1a60694c3eded2f92f5c7fe9af8d72fa06ed1a33a62f0cc1c_1280.jpg",
    createdAt: new Date()
  },
  {
    id: 2,
    title: "Dinacharya: Daily Routine",
    content: "Ayurveda emphasizes the importance of daily routines (Dinacharya) aligned with natural cycles. Waking before sunrise, scraping the tongue, oil pulling, self-massage with oils (abhyanga), and eating meals at consistent times can significantly enhance health and balance doshas.",
    imageUrl: "https://pixabay.com/get/g0df962a08a93c14a2e0a28732b3d9d37a8fdbae4a33c4e252aa9992fbe1c1fb257c27c60cd1c6a06e4a7ea55c7ff3cfb6eadbb1e8f8eca05e9c9c5fac96af9a0_1280.jpg",
    createdAt: new Date()
  },
  {
    id: 3,
    title: "Tastes as Medicine",
    content: "Ayurveda classifies food into six tastes (rasas): sweet, sour, salty, pungent, bitter, and astringent. Each taste has specific effects on doshas. A balanced diet should include all six tastes, with proportions adjusted according to your constitution and current imbalances.",
    imageUrl: "https://pixabay.com/get/ge2d7b0b72cfdea34b823f4d13c8e9f19b2f9e15a13ce8bbc9ddd16c0ff45cff8d9d9f1cc53d0fe1bc0c4a99a50fbf85cd7ff2a3e01f8f11cc2dbb1f59747a38e_1280.jpg",
    createdAt: new Date()
  },
  {
    id: 4,
    title: "Seasonal Living (Ritucharya)",
    content: "Ayurveda teaches that we should align our diet, activities, and lifestyle with the changing seasons to maintain balance. Each season aggravates certain doshas, and following seasonal routines (Ritucharya) helps prevent seasonal imbalances and related disorders.",
    imageUrl: "https://images.unsplash.com/photo-1609102026723-71e59e6a444e?w=1080&auto=format&fit=crop&q=80",
    createdAt: new Date()
  }
];

export function FactsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goToNext = useCallback(() => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % facts.length);
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 500);
  }, [isTransitioning]);

  const goToPrevious = useCallback(() => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentIndex((prevIndex) => (prevIndex - 1 + facts.length) % facts.length);
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 500);
  }, [isTransitioning]);

  // Auto-rotate carousel
  useEffect(() => {
    const interval = setInterval(goToNext, 8000);
    return () => clearInterval(interval);
  }, [goToNext]);

  return (
    <div className="relative overflow-hidden rounded-xl h-[500px] natural-shadow">
      {/* Carousel slides */}
      <div 
        className="h-full w-full relative"
        style={{ backgroundColor: "rgba(0, 0, 0, 0.1)" }}
      >
        {facts.map((fact, index) => (
          <div 
            key={fact.id}
            className={`absolute top-0 left-0 w-full h-full transition-opacity duration-500 ${
              index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
            }`}
          >
            {/* Background image with overlay */}
            <div className="absolute inset-0">
              <img 
                src={fact.imageUrl} 
                alt={fact.title} 
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50"></div>
            </div>
            
            {/* Content */}
            <div className="absolute inset-0 flex items-center justify-center p-8">
              <div className="text-center max-w-3xl">
                <h2 className="font-heading text-4xl md:text-5xl text-white mb-4">
                  {fact.title}
                </h2>
                <p className="text-white text-lg mb-6">
                  {fact.content}
                </p>
                <div className="flex gap-4 justify-center">
                  <Button
                    className="bg-secondary hover:bg-secondary-light text-secondary-foreground"
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Navigation */}
      <Button 
        className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 rounded-full w-10 h-10 p-0 bg-white bg-opacity-20 backdrop-blur-sm text-white hover:bg-white hover:bg-opacity-30"
        onClick={goToPrevious}
      >
        <i className="ri-arrow-left-s-line"></i>
      </Button>
      <Button 
        className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 rounded-full w-10 h-10 p-0 bg-white bg-opacity-20 backdrop-blur-sm text-white hover:bg-white hover:bg-opacity-30"
        onClick={goToNext}
      >
        <i className="ri-arrow-right-s-line"></i>
      </Button>
      
      {/* Indicators */}
      <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2 z-20">
        {facts.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex ? "bg-white w-8" : "bg-white bg-opacity-50"
            }`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
}