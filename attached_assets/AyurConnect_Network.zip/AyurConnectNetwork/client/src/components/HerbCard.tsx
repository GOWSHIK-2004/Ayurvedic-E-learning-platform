import { HerbInfo } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";

interface HerbCardProps {
  herb: HerbInfo;
}

export function HerbCard({ herb }: HerbCardProps) {
  return (
    <Card className="bg-white rounded-lg natural-shadow overflow-hidden">
      <img
        src={herb.image}
        alt={`${herb.name} herb`}
        className="w-full h-32 object-cover"
      />
      
      <CardContent className="p-4">
        <h3 className="font-heading text-lg text-earth font-semibold">{herb.name}</h3>
        <p className="text-xs text-secondary font-medium uppercase tracking-wide mt-1">
          {herb.category}
        </p>
        <p className="mt-2 text-earth text-sm">{herb.description}</p>
      </CardContent>
    </Card>
  );
}
