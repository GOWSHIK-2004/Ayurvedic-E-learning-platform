import { useContext, useState } from "react";
import { UserContext } from "@/App";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function UserSidebar() {
  const { user } = useContext(UserContext);
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [uploading, setUploading] = useState(false);

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(e.target.files);
    }
  };

  // Handle file upload
  const handleUpload = async () => {
    if (!selectedFiles || !user) {
      toast({
        title: "No files selected",
        description: "Please select PDF files to upload",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      const formData = new FormData();
      formData.append("userId", user.id.toString());
      
      for (let i = 0; i < selectedFiles.length; i++) {
        formData.append("pdf", selectedFiles[i]);
      }

      const response = await fetch("/api/pdfs/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      toast({
        title: "Upload successful",
        description: "Your PDFs have been uploaded successfully",
      });

      // Clear selected files
      setSelectedFiles(null);
      const fileInput = document.getElementById("pdfUpload") as HTMLInputElement;
      if (fileInput) {
        fileInput.value = "";
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  // Default avatar and name for when user is not logged in
  const displayName = user?.displayName || "Guest";
  const dosha = user?.dosha || "Unknown Dosha";
  const specialization = user?.specialization || "Ayurveda Enthusiast";

  return (
    <div>
      {/* User Profile Card */}
      <Card className="bg-white rounded-xl natural-shadow mb-6 overflow-hidden">
        {/* Profile Header with Ayurvedic Plant Background */}
        <div className="h-32 bg-cover bg-center" style={{ backgroundImage: "url('https://pixabay.com/get/gf3d385e5a43723477576a50a1c7cf0839a9ce36d11de575dd268f19b0db2ac8101b8143aae31bbd1aaf1298cb3c6839594ae9cee493e63f85f1961bd8ea5e26e_1280.jpg')" }}></div>

        {/* Profile Info */}
        <CardContent className="p-5 -mt-16">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-4 border-white mx-auto bg-cream flex items-center justify-center">
              {/* Dosha Icon - Using a plant icon as default */}
              <i className="ri-leaf-line text-4xl text-primary"></i>
            </div>

            <div className="mt-3 text-center">
              <h3 className="font-heading text-2xl text-earth font-semibold">
                {displayName}
              </h3>
              <p className="text-earth-light text-sm mt-1">
                Ayurvedic Practitioner • {dosha}
              </p>

              <div className="flex justify-center mt-3">
                <span className="px-3 py-1 bg-cream rounded-full text-xs text-primary flex items-center mr-2">
                  <i className="ri-plant-line mr-1"></i> {specialization}
                </span>
                <span className="px-3 py-1 bg-cream rounded-full text-xs text-primary flex items-center">
                  <i className="ri-mental-health-line mr-1"></i> Yoga
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload PDFs Section */}
      <Card className="bg-white rounded-xl natural-shadow">
        <CardContent className="p-5">
          <h3 className="font-heading text-xl text-earth font-semibold mb-4 flex items-center">
            <i className="ri-file-pdf-line text-accent mr-2"></i> Upload PDFs
          </h3>

          {/* Upload Form */}
          <div className="space-y-4">
            {/* File Upload */}
            <div className="relative">
              <label htmlFor="pdfUpload" className="block w-full p-4 border-2 border-dashed border-primary bg-cream rounded-lg text-center cursor-pointer hover:bg-cream-dark transition-all">
                <i className="ri-upload-cloud-2-line text-2xl text-primary mb-1"></i>
                <span className="block text-sm text-earth">
                  Drop Ayurvedic texts or click to browse
                </span>
                <input
                  id="pdfUpload"
                  type="file"
                  className="hidden"
                  accept=".pdf"
                  multiple
                  onChange={handleFileChange}
                />
              </label>
            </div>

            {/* List of Uploaded Files */}
            <div className="border border-cream-dark rounded-lg p-2 bg-cream min-h-[50px]">
              {selectedFiles && selectedFiles.length > 0 ? (
                <ul className="text-sm text-earth">
                  {Array.from(selectedFiles).map((file, index) => (
                    <li key={index} className="mb-1 last:mb-0">
                      {file.name}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-earth-light text-sm italic">No files selected</p>
              )}
            </div>

            {/* Upload Button */}
            <button
              className={`w-full py-2 px-4 ${
                uploading
                  ? "bg-primary-light"
                  : "bg-primary hover:bg-primary-light"
              } text-white rounded-lg transition-all flex items-center justify-center`}
              onClick={handleUpload}
              disabled={uploading || !selectedFiles}
            >
              {uploading ? (
                <>
                  <i className="ri-loader-2-line animate-spin mr-2"></i> Uploading...
                </>
              ) : (
                <>
                  <i className="ri-upload-2-line mr-2"></i> Upload Documents
                </>
              )}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
