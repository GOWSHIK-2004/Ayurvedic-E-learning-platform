import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-earth text-cream mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between">
          {/* Logo & About */}
          <div className="mb-6 md:mb-0 md:w-1/3">
            <div className="flex items-center mb-3">
              <i className="ri-plant-line text-2xl text-secondary mr-2"></i>
              <h2 className="font-heading text-xl font-semibold">Vedic Genie</h2>
            </div>
            <p className="text-cream-dark text-sm">
              Connecting Ayurvedic practitioners, students and enthusiasts in a
              community of ancient wisdom and modern practice.
            </p>
          </div>

          {/* Quick Links */}
          <div className="mb-6 md:mb-0">
            <h3 className="font-heading text-lg font-semibold mb-3">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-cream-dark hover:text-secondary transition-all">
                    Home
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/forum">
                  <a className="text-cream-dark hover:text-secondary transition-all">
                    Forum
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/chat">
                  <a className="text-cream-dark hover:text-secondary transition-all">
                    Resources
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-cream-dark hover:text-secondary transition-all">
                    About Us
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Doshas */}
          <div className="mb-6 md:mb-0">
            <h3 className="font-heading text-lg font-semibold mb-3">
              Dosha Knowledge
            </h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                  Vata (Air & Ether)
                </a>
              </li>
              <li>
                <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                  Pitta (Fire & Water)
                </a>
              </li>
              <li>
                <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                  Kapha (Earth & Water)
                </a>
              </li>
              <li>
                <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                  Dosha Quiz
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading text-lg font-semibold mb-3">
              Connect With Us
            </h3>
            <div className="flex space-x-4">
              <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                <i className="ri-instagram-line text-xl"></i>
              </a>
              <a href="#" className="text-cream-dark hover:text-secondary transition-all">
                <i className="ri-youtube-fill text-xl"></i>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-cream-dark mt-8 pt-6 text-center">
          <p className="text-cream-dark text-sm">
            © {new Date().getFullYear()} Vedic Genie. All rights reserved.
          </p>
          <p className="font-script text-center text-secondary text-2xl mt-3">
            "May all beings be happy and healthy"
          </p>
        </div>
      </div>
    </footer>
  );
}
