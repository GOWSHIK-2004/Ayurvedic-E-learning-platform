import { HerbCard } from "./HerbCard";
import { HerbInfo } from "@/lib/types";

export default function AyurvedicWisdom() {
  // Herb data
  const herbs: HerbInfo[] = [
    {
      id: 1,
      name: "Ashwagandha",
      category: "Winter Rasayana",
      description: "Perfect for Vata season to strengthen immunity and combat stress.",
      image: "https://pixabay.com/get/g4b4750159abc98e29f6a03896a8e29b8fadb551ec333ff1822803967b1b2dbb190873fe91997562052e72e1d49d2839b69b615601c0ac6b1cce2a1003ade3ef4_1280.jpg"
    },
    {
      id: 2,
      name: "Turmeric",
      category: "All-Season Support",
      description: "Anti-inflammatory properties balance all doshas and support joint health.",
      image: "https://pixabay.com/get/g0a1f478b3c679f78be7c5cb3abb39f8ebb75d6e9792b9ed3308b1ed952938f1f4de830df565339a20684c484a627214c0851481ff5b86e5f27df2bc22553f1ff_1280.jpg"
    },
    {
      id: 3,
      name: "Coriander",
      category: "Summer Coolant",
      description: "Cooling herb that pacifies Pitta during summer months.",
      image: "https://images.unsplash.com/photo-1600398819731-cd8d71dbdff5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225"
    },
    {
      id: 4,
      name: "Neem",
      category: "Spring Detoxifier",
      description: "Bitter tonic for spring cleansing and purifying the blood.",
      image: "https://pixabay.com/get/g097db3cce7bd7ef05101124f4a68c3bc263c185b6bab60904e5c5abec0fbffcf912ad264ad23cc08cc608c75cc4c69c7686f8155770d181226ed9186d23f17ac_1280.jpg"
    }
  ];

  return (
    <div className="mt-16 relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1506459225024-1428097a7e18?q=80&w=200&auto=format&fit=crop')] opacity-5 rounded-xl"></div>
      
      {/* Content */}
      <div className="relative bg-cream-dark rounded-xl natural-shadow p-8">
        <div className="text-center mb-10">
          <h2 className="font-heading text-3xl text-earth mb-3">Seasonal Ayurvedic Wisdom</h2>
          <p className="text-earth-light max-w-2xl mx-auto">Connect with nature's rhythms through these seasonal herbs and practices</p>
        </div>
        
        {/* Herb Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {herbs.map(herb => (
            <HerbCard key={herb.id} herb={herb} />
          ))}
        </div>
        
        {/* Wisdom Quote */}
        <div className="mt-10 text-center">
          <p className="font-script text-accent text-3xl">"Ritucharya - living in harmony with nature's seasons - is the foundation of Ayurvedic health"</p>
        </div>
      </div>
    </div>
  );
}
