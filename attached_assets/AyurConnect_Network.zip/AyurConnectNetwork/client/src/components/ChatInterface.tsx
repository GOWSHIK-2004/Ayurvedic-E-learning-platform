import { useState, useRef, useEffect, useContext } from "react";
import { UserContext } from "@/App";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Message } from "@/lib/types";

export default function ChatInterface() {
  const { user } = useContext(UserContext);
  const { toast } = useToast();
  const [chatMode, setChatMode] = useState("pdf");
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const chatHistoryRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of chat history when messages change
  useEffect(() => {
    if (chatHistoryRef.current) {
      chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
    }
  }, [messages]);

  // Add initial system message
  useEffect(() => {
    setMessages([
      {
        id: 0,
        userId: 0,
        content: "Welcome to Vedic Genie! I'm here to help with your Ayurvedic questions. You can ask about herbs, doshas, treatments, or upload PDFs for context-based answers.",
        mode: "system",
        createdAt: new Date(),
        user: {
          id: 0,
          username: "VedicGenie",
          displayName: "Vedic Genie"
        }
      }
    ]);
  }, []);

  // Convert messages to the format expected by the Gemini API
  const getConversationHistory = () => {
    return messages
      .filter(msg => msg.userId === (user?.id || -1) || msg.userId === 0) // Only include user and AI messages
      .map(msg => ({
        role: msg.userId === (user?.id || -1) ? "user" : "model",
        content: msg.content
      }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim()) return;
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to use the chat feature",
        variant: "destructive"
      });
      return;
    }

    // Add user message to chat
    const userMessage: Message = {
      id: Date.now(),
      userId: user.id,
      content: question,
      mode: chatMode,
      createdAt: new Date(),
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName
      }
    };

    // Update chat with user message
    setMessages(prev => [...prev, userMessage]);
    
    // Save message to database for persistence
    try {
      await apiRequest("POST", "/api/messages", {
        userId: user.id,
        content: question,
        mode: chatMode
      });
    } catch (error) {
      console.error("Error saving message to database:", error);
      // Continue with AI response even if DB save fails
    }

    setQuestion("");
    setLoading(true);

    try {
      // Get conversation history for context
      const conversationHistory = getConversationHistory();
      
      // Call the Gemini AI API endpoint
      const aiResponseData = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: question,
          conversationHistory: conversationHistory,
          mode: chatMode
        })
      });
      
      if (!aiResponseData.ok) {
        throw new Error('Failed to get AI response');
      }
      
      const responseJson = await aiResponseData.json();
      
      // Create AI response message
      const aiResponse: Message = {
        id: Date.now() + 1,
        userId: 0,
        content: responseJson.response,
        mode: "system",
        createdAt: new Date(),
        user: {
          id: 0,
          username: "VedicGenie",
          displayName: "Vedic Genie"
        }
      };
      
      // Update chat with AI response
      setMessages(prev => [...prev, aiResponse]);
      
      // Save AI response to database
      try {
        await apiRequest("POST", "/api/replies", {
          messageId: userMessage.id,
          content: responseJson.response
        });
      } catch (error) {
        console.error("Error saving AI reply to database:", error);
      }
    } catch (error) {
      console.error("Error getting AI response:", error);
      
      // Show error toast
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive"
      });
      
      // Add fallback response when AI fails
      const fallbackResponse: Message = {
        id: Date.now() + 1,
        userId: 0,
        content: "I apologize, but I'm having trouble connecting to my knowledge base right now. Please try again in a moment.",
        mode: "system",
        createdAt: new Date(),
        user: {
          id: 0,
          username: "VedicGenie",
          displayName: "Vedic Genie"
        }
      };
      
      setMessages(prev => [...prev, fallbackResponse]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Chat Mode Selector */}
      <Card className="bg-white rounded-xl natural-shadow">
        <CardContent className="p-5">
          <h3 className="font-heading text-xl text-earth font-semibold mb-4 flex items-center">
            <i className="ri-chat-voice-line text-primary mr-2"></i> Chat Mode
          </h3>
          
          <div className="relative">
            <Select defaultValue="pdf" onValueChange={setChatMode}>
              <SelectTrigger className="w-full bg-cream">
                <SelectValue placeholder="Select chat mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pdf">PDF Context</SelectItem>
                <SelectItem value="dosha">Dosha Analysis</SelectItem>
                <SelectItem value="herbs">Herbal Guidance</SelectItem>
                <SelectItem value="general">General Ayurveda</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      {/* Question & Chat Interface */}
      <Card className="bg-white rounded-xl natural-shadow overflow-hidden">
        {/* Chat Title */}
        <CardHeader className="bg-primary text-cream p-4 flex flex-row items-center space-x-2">
          <i className="ri-message-3-line"></i>
          <h3 className="font-heading text-xl font-semibold">Your Questions & Conversations</h3>
        </CardHeader>
        
        {/* Chat History Display */}
        <div 
          className="h-64 overflow-y-auto p-4 bg-cream-light"
          ref={chatHistoryRef}
        >
          {messages.map((message, index) => (
            <div 
              key={index} 
              className={`flex mb-4 ${message.userId === (user?.id || -1) ? 'justify-end' : ''}`}
            >
              {message.userId !== (user?.id || -1) && (
                <div className="w-8 h-8 rounded-full bg-secondary flex-shrink-0 flex items-center justify-center">
                  <i className="ri-ancient-gate-line text-white"></i>
                </div>
              )}
              
              <div className={`${message.userId === (user?.id || -1) ? 'mr-3' : 'ml-3'} max-w-3xl`}>
                <div className={`${
                  message.userId === (user?.id || -1) 
                    ? 'bg-primary text-cream rounded-lg rounded-tr-none' 
                    : 'bg-cream rounded-lg rounded-tl-none'
                } p-3 natural-shadow-sm`}>
                  <p className={message.userId === (user?.id || -1) ? 'text-cream' : 'text-earth'}>
                    {message.content}
                  </p>
                </div>
                <p className={`text-xs text-earth-light mt-1 ${message.userId === (user?.id || -1) ? 'text-right' : ''}`}>
                  {message.userId === (user?.id || -1) ? 'You' : message.user?.displayName || 'Vedic Genie'} • Just now
                </p>
              </div>
              
              {message.userId === (user?.id || -1) && (
                <div className="w-8 h-8 rounded-full bg-primary-light flex-shrink-0 flex items-center justify-center">
                  <span className="text-white text-sm font-semibold">
                    {user?.username?.charAt(0).toUpperCase() || 'U'}
                  </span>
                </div>
              )}
            </div>
          ))}
          
          {/* Loading indicator */}
          {loading && (
            <div className="flex mb-4">
              <div className="w-8 h-8 rounded-full bg-secondary flex-shrink-0 flex items-center justify-center">
                <i className="ri-ancient-gate-line text-white"></i>
              </div>
              <div className="ml-3 max-w-3xl">
                <div className="bg-cream rounded-lg rounded-tl-none p-3 natural-shadow-sm">
                  <div className="flex space-x-2 items-center text-earth">
                    <div className="w-2 h-2 bg-earth-light rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-earth-light rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-earth-light rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Question Input Field & Send Button */}
        <div className="border-t border-cream-dark p-4">
          <form className="flex" onSubmit={handleSubmit}>
            <Input
              type="text"
              placeholder="Ask a question about Ayurveda..."
              className="flex-grow border border-cream-dark rounded-l-lg p-3 bg-cream focus:outline-none focus:ring-2 focus:ring-primary"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
            />
            <Button 
              type="submit"
              className="bg-primary hover:bg-primary-light text-white px-4 py-3 rounded-r-lg transition-all flex items-center justify-center"
              disabled={loading}
            >
              <span className="hidden sm:inline mr-2">Ask</span>
              <i className="ri-send-plane-fill"></i>
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}
