import { useState, useEffect } from "react";
import { WisdomQuote } from "@/lib/types";

// Mock wisdom quotes
const wisdomQuotes: WisdomQuote[] = [
  { id: 1, text: "When diet is wrong, medicine is of no use. When diet is correct, medicine is of no need." },
  { id: 2, text: "Health is a state of complete harmony of the body, mind, and spirit." },
  { id: 3, text: "Prevention is better than cure." },
  { id: 4, text: "Every human being is the author of their own health or disease." },
  { id: 5, text: "The way you think, the way you behave, the way you eat, influences your life." },
  { id: 6, text: "Take care of your body. It's the only place you have to live." },
  { id: 7, text: "The natural healing force within each one of us is the greatest force in getting well." },
  { id: 8, text: "The body heals with play, the mind heals with laughter, and the spirit heals with joy." },
];

export default function WisdomBanner() {
  const [quote, setQuote] = useState<WisdomQuote>(wisdomQuotes[0]);
  
  useEffect(() => {
    // Rotate quotes
    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * wisdomQuotes.length);
      setQuote(wisdomQuotes[randomIndex]);
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="bg-primary-light py-3 text-center">
      <div className="container mx-auto px-4">
        <p className="font-script text-xl text-primary-foreground">
          "{quote.text}"
        </p>
      </div>
    </div>
  );
}