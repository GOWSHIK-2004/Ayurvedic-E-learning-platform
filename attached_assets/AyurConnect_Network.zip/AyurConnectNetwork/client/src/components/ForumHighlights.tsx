import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Post } from "@/lib/types";
import ForumCard from "./ForumCard";

export default function ForumHighlights() {
  // We'll simulate data for now since we're not connecting to the real backend yet
  const posts: Post[] = [
    {
      id: 1,
      userId: 2,
      title: "Effective Rasayanas for Vata imbalance?",
      content: "I'm experiencing dry skin and anxiety, classic Vata imbalance. Which rasayanas or formulations have you found most effective for countering these symptoms?",
      tags: ["Vata Dosha", "Rasayana", "Treatment"],
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      user: {
        id: 2,
        username: "RishiAyur",
        displayName: "RishiAyur"
      }
    },
    {
      id: 2,
      userId: 3,
      title: "Modern preparation of Chyawanprash?",
      content: "I'm looking to prepare authentic Chyawanprash at home but struggling to find some traditional ingredients. What modern substitutes are acceptable while maintaining efficacy?",
      tags: ["Formulations", "Herbs", "Preparation"],
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      user: {
        id: 3,
        username: "AyurPrakash",
        displayName: "AyurPrakash"
      }
    },
    {
      id: 3,
      userId: 4,
      title: "Interpreting classic text on Pitta disorders",
      content: "I'm having trouble interpreting a passage from Charaka Samhita regarding Pitta disorders of the blood. Could anyone help translate the Sanskrit terms in modern medical context?",
      tags: ["Pitta Dosha", "Sanskrit", "Texts"],
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      user: {
        id: 4,
        username: "VaidyaSagar",
        displayName: "VaidyaSagar"
      }
    }
  ];

  // In a real application, we would fetch posts from the API
  // const { data: posts, isLoading, error } = useQuery<Post[]>({
  //   queryKey: ["/api/posts"],
  // });

  return (
    <div className="mt-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="font-heading text-2xl text-earth">Popular Discussions</h2>
        <Link href="/forum">
          <a className="text-primary flex items-center hover:text-primary-dark transition-all">
            <span>View All</span>
            <i className="ri-arrow-right-line ml-1"></i>
          </a>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {posts.map((post) => (
          <ForumCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
}
