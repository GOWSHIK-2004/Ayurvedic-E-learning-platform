import { pgTable, text, serial, integer, boolean, timestamp, json, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (updated for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  dosha: text("dosha"),
  specialization: text("specialization"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  postId: integer("post_id").notNull().references(() => posts.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const pdfs = pgTable("pdfs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  filename: text("filename").notNull(),
  path: text("path").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  mode: text("mode").notNull(),
  pdfId: integer("pdf_id").references(() => pdfs.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const replies = pgTable("replies", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").notNull().references(() => messages.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Symptom analyzer related tables
export const bodyParts = pgTable("body_parts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  svgId: text("svg_id").notNull().unique(),
  description: text("description"),
});

export const symptoms = pgTable("symptoms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  bodyPartId: integer("body_part_id").notNull().references(() => bodyParts.id),
});

export const conditions = pgTable("conditions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  doshaImbalance: text("dosha_imbalance"),
  commonSymptoms: text("common_symptoms"),
  ayurvedicTreatment: text("ayurvedic_treatment").notNull(),
});

export const conditionSymptoms = pgTable("condition_symptoms", {
  id: serial("id").primaryKey(),
  conditionId: integer("condition_id").notNull().references(() => conditions.id),
  symptomId: integer("symptom_id").notNull().references(() => symptoms.id),
});

export const ayurvedicFacts = pgTable("ayurvedic_facts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// For Replit Auth
export const upsertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

export const insertPdfSchema = createInsertSchema(pdfs).omit({
  id: true,
  uploadedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertReplySchema = createInsertSchema(replies).omit({
  id: true,
  createdAt: true,
});

export const insertBodyPartSchema = createInsertSchema(bodyParts).omit({
  id: true,
});

export const insertSymptomSchema = createInsertSchema(symptoms).omit({
  id: true,
});

export const insertConditionSchema = createInsertSchema(conditions).omit({
  id: true,
});

export const insertConditionSymptomSchema = createInsertSchema(conditionSymptoms).omit({
  id: true,
});

export const insertAyurvedicFactSchema = createInsertSchema(ayurvedicFacts).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type InsertPdf = z.infer<typeof insertPdfSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertReply = z.infer<typeof insertReplySchema>;
export type InsertBodyPart = z.infer<typeof insertBodyPartSchema>;
export type InsertSymptom = z.infer<typeof insertSymptomSchema>;
export type InsertCondition = z.infer<typeof insertConditionSchema>;
export type InsertConditionSymptom = z.infer<typeof insertConditionSymptomSchema>;
export type InsertAyurvedicFact = z.infer<typeof insertAyurvedicFactSchema>;

export type User = typeof users.$inferSelect;
export type Post = typeof posts.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Pdf = typeof pdfs.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Reply = typeof replies.$inferSelect;
export type BodyPart = typeof bodyParts.$inferSelect;
export type Symptom = typeof symptoms.$inferSelect;
export type Condition = typeof conditions.$inferSelect;
export type ConditionSymptom = typeof conditionSymptoms.$inferSelect;
export type AyurvedicFact = typeof ayurvedicFacts.$inferSelect;
